/**
 * ============================================================================
 * Production Integrations — Barrel Export
 * ============================================================================
 *
 * Every production integration in one import. Each module wraps a real
 * third-party SDK behind the interface defined in the types or service layer,
 * keeping the coupling confined to this directory.
 *
 * Usage:
 *   import { createStripeConnectClient, createAnthropicAIService, ... } from './integrations';
 */

// Payment processing
export { StripeConnectClient, createStripeConnectClient } from './stripe-connect.client';
export type { ConnectedAccountRegistry } from './stripe-connect.client';

// AI text & image generation
export { AnthropicAIServiceImpl, createAnthropicAIService } from './anthropic-ai.service';

// File storage
export { S3FileStorageImpl, createS3FileStorage } from './s3-storage.service';

// Caching
export { RedisCacheImpl, createRedisCache } from './redis-cache.service';

// Event bus
export { NatsEventBusImpl, createNatsEventBus } from './nats-eventbus.service';

// Squarespace migration
export { SquarespaceApiClientImpl, createSquarespaceApiClient } from './squarespace-api.client';
export type {
  SquarespaceExportData,
  SquarespacePage,
  SquarespaceProduct,
  SquarespaceBlogPost,
  SquarespaceMediaAsset,
  SquarespaceNavItem,
} from './squarespace-api.client';

// Document watermarking
export { PdfWatermarkServiceImpl, createPdfWatermarkService } from './watermark.service';
