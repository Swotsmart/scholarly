/**
 * ============================================================================
 * Scholarly Platform — Book Club Service
 * ============================================================================
 *
 * Structured reading programmes with AI-powered discussion materials,
 * facilitator guides, and engagement tracking.
 *
 * @module erudits/services/bookclub
 * @version 1.1.0 — Type-aligned rewrite
 */

import {
  Result, success, failure, Errors,
  BookClub, BookClubSession, BookClubReading, BookClubMember,
  BookClubSessionType,
  EventBus, Cache, ScholarlyConfig, AIService,
  BookClubRepository, BookClubSessionRepository,
  BookClubReadingRepository, BookClubMemberRepository,
  ERUDITS_EVENTS,
} from '../types/erudits.types';

// ============================================================================
// SERVICE DEPENDENCIES
// ============================================================================

interface BookClubDeps {
  eventBus: EventBus;
  cache: Cache;
  config: ScholarlyConfig;
  ai: AIService;
  clubRepo: BookClubRepository;
  sessionRepo: BookClubSessionRepository;
  readingRepo: BookClubReadingRepository;
  memberRepo: BookClubMemberRepository;
}

// ============================================================================
// SERVICE IMPLEMENTATION
// ============================================================================

export class BookClubService {

  constructor(private readonly deps: BookClubDeps) {}

  // ──────────────────────────────────────────────────────────────────────────
  // CLUB LIFECYCLE
  // ──────────────────────────────────────────────────────────────────────────

  async createClub(
    tenantId: string,
    organiserId: string,
    organiserName: string,
    params: {
      name: string;
      description?: string;
      language: string;
      targetYearLevels: string[];
      curriculumCodes?: string[];
      maxMembers?: number;
      isPublic?: boolean;
      startDate?: Date;
      endDate?: Date;
    },
  ): Promise<Result<BookClub>> {
    if (!params.name || params.name.trim().length < 3) {
      return failure(Errors.validation('Book club name must be at least 3 characters'));
    }

    const slug = this.generateSlug(params.name);

    const club: BookClub = {
      id: this.generateId('bc'),
      tenantId,
      createdAt: new Date(),
      updatedAt: new Date(),
      organiserId,
      organiserName,
      name: params.name,
      slug,
      description: params.description,
      language: params.language || 'fr',
      maxParticipants: params.maxMembers,
      maxMembers: params.maxMembers,
      isPublic: params.isPublic ?? false,
      requiresApproval: false,
      subscriptionRequired: false,
      yearLevels: params.targetYearLevels,
      targetYearLevels: params.targetYearLevels,
      curriculumTags: [],
      curriculumCodes: params.curriculumCodes || [],
      startDate: params.startDate,
      endDate: params.endDate,
      timezone: 'Australia/Perth',
      isActive: true,
      participantCount: 0,
      memberCount: 0,
      sessionCount: 0,
      readingCount: 0,
      completionRate: 0,
    };

    const saved = await this.deps.clubRepo.save(tenantId, club);

    await this.deps.eventBus.publish(ERUDITS_EVENTS.BOOKCLUB_CREATED, {
      tenantId, bookClubId: saved.id, organiserId, name: saved.name,
    });

    return success(saved);
  }

  async updateClub(
    tenantId: string,
    clubId: string,
    userId: string,
    updates: Partial<Pick<BookClub, 'name' | 'description' | 'maxMembers' | 'isPublic' | 'isActive' | 'startDate' | 'endDate'>>,
  ): Promise<Result<BookClub>> {
    const club = await this.deps.clubRepo.findById(tenantId, clubId);
    if (!club) return failure(Errors.notFound('Book Club', clubId));
    if (club.organiserId !== userId) {
      return failure(Errors.forbidden('Only the club organiser can edit it'));
    }

    const updated = await this.deps.clubRepo.update(tenantId, clubId, {
      ...updates,
      updatedAt: new Date(),
    });

    return success(updated);
  }

  // ──────────────────────────────────────────────────────────────────────────
  // READING LIST
  // ──────────────────────────────────────────────────────────────────────────

  async addReading(
    tenantId: string,
    clubId: string,
    userId: string,
    reading: {
      title: string;
      author?: string;
      storybookId?: string;
      publicationId?: string;
      externalUrl?: string;
      curriculumCode?: string;
      learningObjectives?: string[];
      readByDate?: Date;
      sortOrder?: number;
    },
  ): Promise<Result<BookClubReading>> {
    const club = await this.deps.clubRepo.findById(tenantId, clubId);
    if (!club) return failure(Errors.notFound('Book Club', clubId));
    if (club.organiserId !== userId) {
      return failure(Errors.forbidden('Only the club organiser can manage the reading list'));
    }

    const existingReadings = await this.deps.readingRepo.findByClub(tenantId, clubId);

    const bookClubReading: BookClubReading = {
      id: this.generateId('bcr'),
      tenantId,
      createdAt: new Date(),
      bookClubId: clubId,
      title: reading.title,
      author: reading.author,
      storybookId: reading.storybookId,
      publicationId: reading.publicationId,
      externalUrl: reading.externalUrl,
      curriculumCode: reading.curriculumCode,
      learningObjectives: reading.learningObjectives || [],
      readByDate: reading.readByDate,
      sortOrder: reading.sortOrder ?? existingReadings.length,
      isComplete: false,
      completionRate: 0,
    };

    const saved = await this.deps.readingRepo.save(tenantId, bookClubReading);

    await this.deps.clubRepo.update(tenantId, clubId, {
      readingCount: existingReadings.length + 1,
      updatedAt: new Date(),
    });

    await this.deps.eventBus.publish(ERUDITS_EVENTS.BOOKCLUB_READING_ASSIGNED, {
      tenantId, bookClubId: clubId, readingId: saved.id, title: saved.title,
    });

    return success(saved);
  }

  async getReadingList(
    tenantId: string,
    clubId: string,
  ): Promise<Result<BookClubReading[]>> {
    const club = await this.deps.clubRepo.findById(tenantId, clubId);
    if (!club) return failure(Errors.notFound('Book Club', clubId));

    const readings = await this.deps.readingRepo.findByClub(tenantId, clubId);
    return success(readings.sort((a: BookClubReading, b: BookClubReading) => a.sortOrder - b.sortOrder));
  }

  // ──────────────────────────────────────────────────────────────────────────
  // SESSION SCHEDULING
  // ──────────────────────────────────────────────────────────────────────────

  async scheduleSession(
    tenantId: string,
    clubId: string,
    userId: string,
    session: {
      title: string;
      sessionType: BookClubSessionType;
      scheduledAt: Date;
      durationMinutes?: number;
      readingId?: string;
      description?: string;
      facilitatorNotes?: string;
      meetingUrl?: string;
    },
  ): Promise<Result<BookClubSession>> {
    const club = await this.deps.clubRepo.findById(tenantId, clubId);
    if (!club) return failure(Errors.notFound('Book Club', clubId));
    if (club.organiserId !== userId) {
      return failure(Errors.forbidden('Only the club organiser can schedule sessions'));
    }

    if (session.readingId) {
      const reading = await this.deps.readingRepo.findById(tenantId, session.readingId);
      if (!reading || reading.bookClubId !== clubId) {
        return failure(Errors.notFound('Reading', session.readingId));
      }
    }

    const existingSessions = await this.deps.sessionRepo.findByClub(tenantId, clubId);

    const bookClubSession: BookClubSession = {
      id: this.generateId('bcs'),
      tenantId,
      createdAt: new Date(),
      bookClubId: clubId,
      title: session.title,
      sessionType: session.sessionType,
      scheduledAt: session.scheduledAt,
      durationMinutes: session.durationMinutes || 60,
      sortOrder: existingSessions.length,
      readingId: session.readingId,
      description: session.description,
      facilitatorNotes: session.facilitatorNotes,
      meetingUrl: session.meetingUrl,
      status: 'scheduled',
      isCompleted: false,
      attendeeCount: 0,
    };

    const saved = await this.deps.sessionRepo.save(tenantId, bookClubSession);

    await this.deps.clubRepo.update(tenantId, clubId, {
      sessionCount: existingSessions.length + 1,
      updatedAt: new Date(),
    });

    await this.deps.eventBus.publish(ERUDITS_EVENTS.BOOKCLUB_SESSION_SCHEDULED, {
      tenantId, bookClubId: clubId, sessionId: saved.id,
      sessionType: saved.sessionType, scheduledAt: saved.scheduledAt.toISOString(),
    });

    return success(saved);
  }

  async completeSession(
    tenantId: string,
    sessionId: string,
    userId: string,
    attendeeIds: string[],
    notes?: string,
  ): Promise<Result<BookClubSession>> {
    const session = await this.deps.sessionRepo.findById(tenantId, sessionId);
    if (!session) return failure(Errors.notFound('Session', sessionId));

    const club = await this.deps.clubRepo.findById(tenantId, session.bookClubId);
    if (!club || club.organiserId !== userId) {
      return failure(Errors.forbidden('Only the club organiser can complete sessions'));
    }

    const updated = await this.deps.sessionRepo.update(tenantId, sessionId, {
      isCompleted: true,
      attendeeCount: attendeeIds.length,
      facilitatorNotes: notes || session.facilitatorNotes,
      status: 'completed',
    });

    for (const attendeeId of attendeeIds) {
      await this.deps.memberRepo.recordAttendance(tenantId, session.bookClubId, attendeeId, sessionId);
    }

    await this.deps.eventBus.publish(ERUDITS_EVENTS.BOOKCLUB_SESSION_COMPLETED, {
      tenantId, bookClubId: session.bookClubId, sessionId,
      attendeeCount: attendeeIds.length,
    });

    return success(updated);
  }

  async getUpcomingSessions(
    tenantId: string,
    clubId: string,
    limit: number = 10,
  ): Promise<Result<BookClubSession[]>> {
    const sessions = await this.deps.sessionRepo.findUpcoming(tenantId, clubId, limit);
    return success(sessions);
  }

  // ──────────────────────────────────────────────────────────────────────────
  // MEMBERSHIP
  // ──────────────────────────────────────────────────────────────────────────

  async joinClub(
    tenantId: string,
    clubId: string,
    userId: string,
    userName: string,
    role: 'member' | 'moderator' | 'organiser' | 'student' | 'facilitator' = 'member',
  ): Promise<Result<BookClubMember>> {
    const club = await this.deps.clubRepo.findById(tenantId, clubId);
    if (!club) return failure(Errors.notFound('Book Club', clubId));
    if (!club.isActive) return failure(Errors.validation('This book club is no longer active'));

    if (club.maxMembers && club.memberCount >= club.maxMembers) {
      return failure(Errors.validation('This book club is full'));
    }

    const existing = await this.deps.memberRepo.findByUserAndClub(tenantId, userId, clubId);
    if (existing) {
      return failure(Errors.conflict('You are already a member of this book club'));
    }

    const member: BookClubMember = {
      id: this.generateId('bcm'),
      tenantId,
      createdAt: new Date(),
      bookClubId: clubId,
      userId,
      displayName: userName,
      userName,
      role,
      isActive: true,
      readingsCompleted: 0,
      sessionsAttended: 0,
      engagementScore: 0,
    };

    const saved = await this.deps.memberRepo.save(tenantId, member);

    await this.deps.clubRepo.update(tenantId, clubId, {
      memberCount: club.memberCount + 1,
      participantCount: club.participantCount + 1,
      updatedAt: new Date(),
    });

    await this.deps.eventBus.publish(ERUDITS_EVENTS.BOOKCLUB_MEMBER_JOINED, {
      tenantId, bookClubId: clubId, userId, role,
    });

    return success(saved);
  }

  async leaveClub(
    tenantId: string,
    clubId: string,
    userId: string,
  ): Promise<Result<void>> {
    const member = await this.deps.memberRepo.findByUserAndClub(tenantId, userId, clubId);
    if (!member) return failure(Errors.notFound('Membership', `${userId}@${clubId}`));

    await this.deps.memberRepo.deactivate(tenantId, member.id);

    const club = await this.deps.clubRepo.findById(tenantId, clubId);
    if (club) {
      await this.deps.clubRepo.update(tenantId, clubId, {
        memberCount: Math.max(0, club.memberCount - 1),
        updatedAt: new Date(),
      });
    }

    return success(undefined);
  }

  async getMembers(
    tenantId: string,
    clubId: string,
  ): Promise<Result<BookClubMember[]>> {
    const club = await this.deps.clubRepo.findById(tenantId, clubId);
    if (!club) return failure(Errors.notFound('Book Club', clubId));

    const members = await this.deps.memberRepo.findByClub(tenantId, clubId);
    return success(members);
  }

  // ──────────────────────────────────────────────────────────────────────────
  // AI-POWERED DISCUSSION MATERIALS
  // ──────────────────────────────────────────────────────────────────────────

  async generateDiscussionQuestions(
    tenantId: string,
    clubId: string,
    readingId: string,
    userId: string,
    options?: {
      questionCount?: number;
      difficultyLevel?: 'beginner' | 'intermediate' | 'advanced';
      focusAreas?: string[];
      targetLanguage?: string;
      includeAnswerKey?: boolean;
    },
  ): Promise<Result<GeneratedDiscussionMaterials>> {
    const club = await this.deps.clubRepo.findById(tenantId, clubId);
    if (!club) return failure(Errors.notFound('Book Club', clubId));
    if (club.organiserId !== userId) {
      return failure(Errors.forbidden('Only the club organiser can generate materials'));
    }

    const reading = await this.deps.readingRepo.findById(tenantId, readingId);
    if (!reading || reading.bookClubId !== clubId) {
      return failure(Errors.notFound('Reading', readingId));
    }

    const questionCount = options?.questionCount || 8;
    const difficulty = options?.difficultyLevel || 'intermediate';
    const language = options?.targetLanguage || club.language;
    const focusAreas = options?.focusAreas || ['comprehension', 'vocabulary', 'cultural context'];

    const systemPrompt = [
      `You are an expert ${club.language === 'fr' ? 'French' : club.language} language educator designing discussion questions.`,
      `Book Club: "${club.name}"`,
      `Target students: Year levels ${club.targetYearLevels.join(', ')}`,
      `Difficulty: ${difficulty}`,
      `Curriculum: ${reading.curriculumCode || club.curriculumCodes.join(', ') || 'General'}`,
      `Learning objectives: ${reading.learningObjectives.join('; ') || 'General comprehension and vocabulary'}`,
      `Focus areas: ${focusAreas.join(', ')}`,
      ``,
      `Generate questions in ${language === 'fr' ? 'French' : language}.`,
      `Questions should span Bloom's taxonomy levels.`,
    ].join('\n');

    const result = await this.deps.ai.complete({
      systemPrompt,
      userPrompt: `Generate ${questionCount} discussion questions for "${reading.title}" by ${reading.author || 'unknown'}. ${
        options?.includeAnswerKey
          ? 'Include suggested answers for each question.'
          : 'Do not include answers.'
      }
Return JSON: { "questions": [{ "question": "...", "bloomsLevel": "remember|understand|apply|analyse|evaluate|create", "focusArea": "...", "suggestedAnswer": "..." }], "icebreaker": "...", "closingReflection": "..." }`,
      maxTokens: this.deps.config.aiMaxTokens,
      temperature: 0.8,
      responseFormat: 'json',
    });

    try {
      const parsed = JSON.parse(result.text) as GeneratedDiscussionMaterials;
      parsed.readingId = readingId;
      parsed.readingTitle = reading.title;
      parsed.generatedAt = new Date();
      return success(parsed);
    } catch {
      return failure(Errors.internal('Failed to parse AI-generated discussion materials'));
    }
  }

  async generateFacilitatorGuide(
    tenantId: string,
    sessionId: string,
    userId: string,
  ): Promise<Result<FacilitatorGuide>> {
    const session = await this.deps.sessionRepo.findById(tenantId, sessionId);
    if (!session) return failure(Errors.notFound('Session', sessionId));

    const club = await this.deps.clubRepo.findById(tenantId, session.bookClubId);
    if (!club || club.organiserId !== userId) {
      return failure(Errors.forbidden('Only the club organiser can generate guides'));
    }

    let reading: BookClubReading | null = null;
    if (session.readingId) {
      reading = await this.deps.readingRepo.findById(tenantId, session.readingId);
    }

    const systemPrompt = [
      `You are an expert facilitator for a ${club.language === 'fr' ? 'French' : club.language} language book club.`,
      `Club: "${club.name}"`,
      `Target year levels: ${club.targetYearLevels.join(', ')}`,
      `Curriculum: ${club.curriculumCodes.join(', ') || 'General'}`,
      `Session type: ${session.sessionType}`,
      `Duration: ${session.durationMinutes} minutes`,
      reading ? `Reading: "${reading.title}" by ${reading.author || 'unknown'}` : '',
      reading?.curriculumCode ? `Aligned to: ${reading.curriculumCode}` : '',
    ].filter(Boolean).join('\n');

    const result = await this.deps.ai.complete({
      systemPrompt,
      userPrompt: `Generate a complete facilitator guide. Return JSON: { "overview": "...", "preSessionChecklist": ["..."], "agenda": [{ "time": "...", "activity": "...", "notes": "..." }], "keyVocabulary": [{ "term": "...", "translation": "...", "context": "..." }], "discussionPrompts": ["..."], "differentiation": { "support": ["..."], "extension": ["..."] }, "assessmentCheckpoints": ["..."] }`,
      maxTokens: this.deps.config.aiMaxTokens,
      temperature: 0.7,
      responseFormat: 'json',
    });

    try {
      const guide = JSON.parse(result.text) as FacilitatorGuide;
      guide.sessionId = sessionId;
      guide.sessionTitle = session.title;
      guide.generatedAt = new Date();
      return success(guide);
    } catch {
      return failure(Errors.internal('Failed to parse AI-generated facilitator guide'));
    }
  }

  // ──────────────────────────────────────────────────────────────────────────
  // ENGAGEMENT & ANALYTICS
  // ──────────────────────────────────────────────────────────────────────────

  async markReadingComplete(
    tenantId: string,
    clubId: string,
    readingId: string,
    userId: string,
  ): Promise<Result<void>> {
    const member = await this.deps.memberRepo.findByUserAndClub(tenantId, userId, clubId);
    if (!member) return failure(Errors.forbidden('You are not a member of this book club'));

    const reading = await this.deps.readingRepo.findById(tenantId, readingId);
    if (!reading || reading.bookClubId !== clubId) {
      return failure(Errors.notFound('Reading', readingId));
    }

    await this.deps.memberRepo.update(tenantId, member.id, {
      readingsCompleted: member.readingsCompleted + 1,
    });

    // Recalculate engagement score
    const updatedMember = await this.deps.memberRepo.findById(tenantId, member.id);
    if (updatedMember) {
      const club = await this.deps.clubRepo.findById(tenantId, clubId);
      const totalReadings = club?.readingCount || 1;
      const totalSessions = club?.sessionCount || 1;

      const readingScore = Math.min(100, (updatedMember.readingsCompleted / totalReadings) * 100);
      const attendanceScore = Math.min(100, (updatedMember.sessionsAttended / totalSessions) * 100);
      const engagementScore = Math.round((readingScore * 0.6) + (attendanceScore * 0.4));

      await this.deps.memberRepo.update(tenantId, member.id, { engagementScore });
    }

    return success(undefined);
  }

  async getClubAnalytics(
    tenantId: string,
    clubId: string,
  ): Promise<Result<BookClubAnalytics>> {
    const club = await this.deps.clubRepo.findById(tenantId, clubId);
    if (!club) return failure(Errors.notFound('Book Club', clubId));

    const members = await this.deps.memberRepo.findByClub(tenantId, clubId);
    const sessions = await this.deps.sessionRepo.findByClub(tenantId, clubId);
    const readings = await this.deps.readingRepo.findByClub(tenantId, clubId);

    const activeMembers = members.filter((m: BookClubMember) => m.isActive);
    const completedSessions = sessions.filter((s: BookClubSession) => s.isCompleted);

    const avgEngagement = activeMembers.length > 0
      ? Math.round(activeMembers.reduce((sum: number, m: BookClubMember) => sum + m.engagementScore, 0) / activeMembers.length)
      : 0;

    const avgAttendance = completedSessions.length > 0
      ? Math.round(completedSessions.reduce((sum: number, s: BookClubSession) => sum + s.attendeeCount, 0) / completedSessions.length)
      : 0;

    return success({
      clubId,
      clubName: club.name,
      totalMembers: club.memberCount,
      activeMembers: activeMembers.length,
      totalReadings: readings.length,
      completedReadings: readings.filter((r: BookClubReading) => r.isComplete).length,
      totalSessions: sessions.length,
      completedSessions: completedSessions.length,
      averageAttendance: avgAttendance,
      averageEngagementScore: avgEngagement,
      topMembers: activeMembers
        .sort((a: BookClubMember, b: BookClubMember) => b.engagementScore - a.engagementScore)
        .slice(0, 5)
        .map((m: BookClubMember) => ({ userName: m.userName, engagementScore: m.engagementScore })),
    });
  }

  // ──────────────────────────────────────────────────────────────────────────
  // PRIVATE HELPERS
  // ──────────────────────────────────────────────────────────────────────────

  private generateSlug(title: string): string {
    return title.toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .substring(0, 80);
  }

  private generateId(prefix: string): string {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 10);
    return `${prefix}_${timestamp}${random}`;
  }
}

// ============================================================================
// AI-GENERATED MATERIAL TYPES
// ============================================================================

export interface GeneratedDiscussionMaterials {
  readingId?: string;
  readingTitle?: string;
  generatedAt?: Date;
  questions: Array<{
    question: string;
    bloomsLevel: 'remember' | 'understand' | 'apply' | 'analyse' | 'evaluate' | 'create';
    focusArea: string;
    suggestedAnswer?: string;
  }>;
  icebreaker: string;
  closingReflection: string;
}

export interface FacilitatorGuide {
  sessionId?: string;
  sessionTitle?: string;
  generatedAt?: Date;
  overview: string;
  preSessionChecklist: string[];
  agenda: Array<{ time: string; activity: string; notes: string }>;
  keyVocabulary: Array<{ term: string; translation: string; context: string }>;
  discussionPrompts: string[];
  differentiation: { support: string[]; extension: string[] };
  assessmentCheckpoints: string[];
}

export interface BookClubAnalytics {
  clubId: string;
  clubName: string;
  totalMembers: number;
  activeMembers: number;
  totalReadings: number;
  completedReadings: number;
  totalSessions: number;
  completedSessions: number;
  averageAttendance: number;
  averageEngagementScore: number;
  topMembers: Array<{ userName: string; engagementScore: number }>;
}
