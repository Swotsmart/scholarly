import { test, expect, request } from '@playwright/test';

/**
 * API Endpoint Smoke Tests
 *
 * Validates that all mounted API routes respond with valid HTTP status
 * codes (not 500). These test the Express backend at API_URL, not the
 * Next.js frontend. They run without browser context for speed.
 *
 * These endpoints map to packages/api/src/routes/*.ts
 */

const API_URL = process.env.PLAYWRIGHT_API_URL || 'http://localhost:3002';

test.describe('API Health', () => {
  test('API server is reachable', async ({ }) => {
    const ctx = await request.newContext({ baseURL: API_URL });
    const res = await ctx.get('/health');
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });
});

test.describe('Auth Endpoints', () => {
  test('POST /api/v1/auth/login accepts request', async ({ }) => {
    const ctx = await request.newContext({ baseURL: API_URL });
    const res = await ctx.post('/api/v1/auth/login', {
      data: { email: 'teacher@scholarly.app', password: 'demo123' },
    });
    // Should return 200 (success) or 401 (bad creds) — never 500
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });
});

test.describe('Content Endpoints', () => {
  test('GET /api/v1/content responds', async ({ }) => {
    const ctx = await request.newContext({ baseURL: API_URL });
    const res = await ctx.get('/api/v1/content');
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });
});

test.describe('Curriculum Endpoints', () => {
  test('GET /api/v1/curriculum/standards responds', async ({ }) => {
    const ctx = await request.newContext({ baseURL: API_URL });
    const res = await ctx.get('/api/v1/curriculum/standards');
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });

  test('GET /api/v1/curriculum/lesson-plans responds', async ({ }) => {
    const ctx = await request.newContext({ baseURL: API_URL });
    const res = await ctx.get('/api/v1/curriculum/lesson-plans');
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });
});

test.describe('Analytics Endpoints', () => {
  test('GET /api/v1/analytics responds', async ({ }) => {
    const ctx = await request.newContext({ baseURL: API_URL });
    const res = await ctx.get('/api/v1/analytics');
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });
});

test.describe('User Endpoints', () => {
  test('GET /api/v1/users responds', async ({ }) => {
    const ctx = await request.newContext({ baseURL: API_URL });
    const res = await ctx.get('/api/v1/users');
    // May return 401 without auth — that's fine, not 500
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });
});

test.describe('Relief Endpoints', () => {
  test('GET /api/v1/relief/teachers responds', async ({ }) => {
    const ctx = await request.newContext({ baseURL: API_URL });
    const res = await ctx.get('/api/v1/relief/teachers');
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });

  test('GET /api/v1/relief/stats responds', async ({ }) => {
    const ctx = await request.newContext({ baseURL: API_URL });
    const res = await ctx.get('/api/v1/relief/stats');
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });
});

test.describe('Collaboration Endpoints', () => {
  test('GET /api/v1/collaboration/lesson-plans responds', async ({ }) => {
    const ctx = await request.newContext({ baseURL: API_URL });
    const res = await ctx.get('/api/v1/collaboration/lesson-plans');
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });
});

test.describe('Storybook Endpoints', () => {
  test('GET /api/v1/storybook route responds', async ({ }) => {
    const ctx = await request.newContext({ baseURL: API_URL });
    const res = await ctx.get('/api/v1/storybook');
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });
});

test.describe('Developer Portal Endpoints', () => {
  test('GET /api/v1/developer-portal responds', async ({ }) => {
    const ctx = await request.newContext({ baseURL: API_URL });
    const res = await ctx.get('/api/v1/developer-portal');
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });
});
