import { test, expect } from '@playwright/test';
import { navigateTo, waitForPageReady, StateHelper } from '../helpers';

/**
 * Early Years (Little Explorers) E2E Tests
 *
 * The early-years route group serves ages 3-7 with phonics,
 * numeracy, and activity content. These pages also power the
 * Mati mobile app via WebView bridge.
 *
 * Uses teacher auth state (early-years pages may require any auth).
 */

test.describe('Early Years', () => {
  test('landing page loads', async ({ page }) => {
    await navigateTo(page, '/early-years');
    await waitForPageReady(page);
    await new StateHelper(page).expectNoErrors();
  });

  test('phonics page loads', async ({ page }) => {
    await navigateTo(page, '/early-years/phonics');
    await new StateHelper(page).expectNoErrors();
  });

  test('enroll page loads', async ({ page }) => {
    await navigateTo(page, '/early-years/enroll');
    await new StateHelper(page).expectNoErrors();
  });

  test('parent page loads', async ({ page }) => {
    await navigateTo(page, '/early-years/parent');
    await new StateHelper(page).expectNoErrors();
  });

  test('points page loads', async ({ page }) => {
    await navigateTo(page, '/early-years/points');
    await new StateHelper(page).expectNoErrors();
  });

  test('settings page loads', async ({ page }) => {
    await navigateTo(page, '/early-years/settings');
    await new StateHelper(page).expectNoErrors();
  });
});
