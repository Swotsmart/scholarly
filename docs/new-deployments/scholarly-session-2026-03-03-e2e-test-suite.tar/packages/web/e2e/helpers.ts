import { Page, Locator, expect } from '@playwright/test';

/**
 * Scholarly E2E Test Helpers
 *
 * Page object models and utilities shared across all test suites.
 * These abstractions insulate tests from DOM changes — if a button
 * text or selector changes, you fix it once here, not in 50 tests.
 */

// =============================================================================
// Navigation Helpers
// =============================================================================

export async function navigateTo(page: Page, path: string) {
  await page.goto(path);
  await page.waitForLoadState('networkidle');
}

export async function waitForPageReady(page: Page) {
  // Wait for skeleton loaders to disappear (our loading pattern)
  await page.waitForFunction(() => {
    const skeletons = document.querySelectorAll('[class*="skeleton"], [class*="animate-pulse"]');
    return skeletons.length === 0;
  }, { timeout: 15_000 }).catch(() => {
    // Timeout is acceptable — some pages may have permanent skeleton areas
  });
}

// =============================================================================
// Sidebar Page Object
// =============================================================================

export class SidebarHelper {
  constructor(private page: Page) {}

  get sidebar(): Locator {
    return this.page.locator('[data-testid="sidebar"], aside').first();
  }

  async navigateToSection(label: string) {
    await this.sidebar.getByText(label, { exact: false }).first().click();
    await this.page.waitForLoadState('networkidle');
  }

  async expectVisible() {
    await expect(this.sidebar).toBeVisible();
  }
}

// =============================================================================
// Card Helpers (shadcn/ui pattern)
// =============================================================================

export class CardHelper {
  constructor(private page: Page) {}

  /** Get all visible cards on the page */
  get cards(): Locator {
    return this.page.locator('[class*="rounded-lg border"], [class*="CardContent"]');
  }

  /** Get a card containing specific text */
  cardWithText(text: string): Locator {
    return this.cards.filter({ hasText: text }).first();
  }

  /** Assert at least N cards are visible */
  async expectMinCards(n: number) {
    await expect(this.cards.first()).toBeVisible({ timeout: 10_000 });
    const count = await this.cards.count();
    expect(count).toBeGreaterThanOrEqual(n);
  }
}

// =============================================================================
// AI Insight Helpers (LIS integration pattern)
// =============================================================================

export class AIInsightHelper {
  constructor(private page: Page) {}

  /** LIS insight cards have purple gradient styling */
  get insightCards(): Locator {
    return this.page.locator('[class*="purple"]').filter({ hasText: /LIS|AI|insight/i });
  }

  /** Ask Issy chat panel */
  get askIssyInput(): Locator {
    return this.page.locator('input[placeholder*="Ask Issy"], input[placeholder*="ask Issy"], input[placeholder*="e.g."]').first();
  }

  get askIssyButton(): Locator {
    return this.page.locator('button').filter({ has: this.page.locator('svg') }).last();
  }

  async sendIssyMessage(message: string) {
    await this.askIssyInput.fill(message);
    await this.askIssyButton.click();
    // Wait for response (spinner disappears, response appears)
    await this.page.waitForSelector('[class*="purple"] p', { timeout: 30_000 });
  }

  async expectInsightsPresent() {
    // AI insights may or may not be present depending on data
    // This just checks the infrastructure is working
    const count = await this.insightCards.count();
    return count > 0;
  }
}

// =============================================================================
// Loading & Error State Helpers
// =============================================================================

export class StateHelper {
  constructor(private page: Page) {}

  /** Check that loading skeletons appear then resolve */
  async expectLoadingThenContent(contentSelector: string) {
    // Content should eventually appear
    await expect(this.page.locator(contentSelector).first()).toBeVisible({ timeout: 15_000 });
  }

  /** Check for error state cards */
  async expectNoErrors() {
    const errorCards = this.page.locator('[class*="border-red"]');
    const count = await errorCards.count();
    expect(count).toBe(0);
  }

  /** Check for empty state messages */
  async isEmptyState(): Promise<boolean> {
    const emptyMessages = this.page.locator('text=/no.*found|no.*available|no.*yet/i');
    return (await emptyMessages.count()) > 0;
  }
}

// =============================================================================
// Table Helpers
// =============================================================================

export class TableHelper {
  constructor(private page: Page, private tableSelector = 'table') {}

  get table(): Locator {
    return this.page.locator(this.tableSelector).first();
  }

  get rows(): Locator {
    return this.table.locator('tbody tr');
  }

  get headers(): Locator {
    return this.table.locator('thead th');
  }

  async expectRowCount(min: number) {
    await expect(this.rows.first()).toBeVisible({ timeout: 10_000 });
    const count = await this.rows.count();
    expect(count).toBeGreaterThanOrEqual(min);
  }

  async expectHeaders(expectedHeaders: string[]) {
    for (const header of expectedHeaders) {
      await expect(this.table.getByText(header)).toBeVisible();
    }
  }
}

// =============================================================================
// Badge Helpers
// =============================================================================

export async function expectBadge(page: Page, text: string) {
  await expect(page.locator('[class*="badge"], [class*="Badge"]').filter({ hasText: text }).first()).toBeVisible();
}

// =============================================================================
// API Intercept Helpers
// =============================================================================

/** Wait for a specific API call to complete */
export async function waitForAPI(page: Page, urlPattern: string | RegExp): Promise<void> {
  await page.waitForResponse(
    (response) => {
      const url = response.url();
      if (typeof urlPattern === 'string') return url.includes(urlPattern);
      return urlPattern.test(url);
    },
    { timeout: 15_000 }
  );
}

/** Intercept API and return mock for offline testing */
export async function mockAPI(page: Page, urlPattern: string, data: unknown, status = 200) {
  await page.route(`**${urlPattern}**`, (route) => {
    route.fulfill({
      status,
      contentType: 'application/json',
      body: JSON.stringify(data),
    });
  });
}
