import { test, expect } from '@playwright/test';
import { navigateTo, waitForPageReady, StateHelper, CardHelper, AIInsightHelper } from '../helpers';

/**
 * Parent Module E2E Tests
 *
 * Pre-authenticated as: parent@scholarly.app (David Smith)
 * 18 pages covering: dashboard, children, progress, messages,
 * payments, tutoring, portfolio, calendar.
 */

// =============================================================================
// Dashboard & Core
// =============================================================================

test.describe('Parent Dashboard', () => {
  test.beforeEach(async ({ page }) => {
    await navigateTo(page, '/parent/dashboard');
    await waitForPageReady(page);
  });

  test('loads without errors', async ({ page }) => {
    await new StateHelper(page).expectNoErrors();
  });

  test('shows heading', async ({ page }) => {
    await expect(page.getByText(/dashboard|welcome/i).first()).toBeVisible();
  });

  test('shows children summary or family stats', async ({ page }) => {
    const cards = new CardHelper(page);
    expect(await cards.cards.count()).toBeGreaterThanOrEqual(1);
  });
});

test.describe('Parent Landing', () => {
  test('loads without errors', async ({ page }) => {
    await navigateTo(page, '/parent');
    await new StateHelper(page).expectNoErrors();
  });
});

// =============================================================================
// Children
// =============================================================================

test.describe('Children', () => {
  test('loads without errors', async ({ page }) => {
    await navigateTo(page, '/parent/children');
    await new StateHelper(page).expectNoErrors();
  });

  test('shows child cards or empty state', async ({ page }) => {
    await navigateTo(page, '/parent/children');
    await waitForPageReady(page);
    const isEmpty = await new StateHelper(page).isEmptyState();
    const cards = await new CardHelper(page).cards.count();
    expect(isEmpty || cards > 0).toBeTruthy();
  });
});

// =============================================================================
// Progress (3 pages)
// =============================================================================

test.describe('Progress', () => {
  test('overview loads', async ({ page }) => {
    await navigateTo(page, '/parent/progress');
    await new StateHelper(page).expectNoErrors();
  });

  test('attendance sub-page loads', async ({ page }) => {
    await navigateTo(page, '/parent/progress/attendance');
    await new StateHelper(page).expectNoErrors();
  });

  test('grades sub-page loads', async ({ page }) => {
    await navigateTo(page, '/parent/progress/grades');
    await new StateHelper(page).expectNoErrors();
  });

  test('learning sub-page loads', async ({ page }) => {
    await navigateTo(page, '/parent/progress/learning');
    await new StateHelper(page).expectNoErrors();
  });
});

// =============================================================================
// Messages (3 pages)
// =============================================================================

test.describe('Messages', () => {
  test('inbox loads', async ({ page }) => {
    await navigateTo(page, '/parent/messages');
    await new StateHelper(page).expectNoErrors();
  });

  test('teacher messages loads', async ({ page }) => {
    await navigateTo(page, '/parent/messages/teachers');
    await new StateHelper(page).expectNoErrors();
  });

  test('tutor messages loads', async ({ page }) => {
    await navigateTo(page, '/parent/messages/tutors');
    await new StateHelper(page).expectNoErrors();
  });
});

// =============================================================================
// Payments (3 pages)
// =============================================================================

test.describe('Payments', () => {
  test('overview loads', async ({ page }) => {
    await navigateTo(page, '/parent/payments');
    await new StateHelper(page).expectNoErrors();
  });

  test('history sub-page loads', async ({ page }) => {
    await navigateTo(page, '/parent/payments/history');
    await new StateHelper(page).expectNoErrors();
  });

  test('subscriptions sub-page loads', async ({ page }) => {
    await navigateTo(page, '/parent/payments/subscriptions');
    await new StateHelper(page).expectNoErrors();
  });
});

// =============================================================================
// Tutoring (3 pages)
// =============================================================================

test.describe('Tutoring', () => {
  test('overview loads', async ({ page }) => {
    await navigateTo(page, '/parent/tutoring');
    await new StateHelper(page).expectNoErrors();
  });

  test('bookings sub-page loads', async ({ page }) => {
    await navigateTo(page, '/parent/tutoring/bookings');
    await new StateHelper(page).expectNoErrors();
  });

  test('search sub-page loads', async ({ page }) => {
    await navigateTo(page, '/parent/tutoring/search');
    await new StateHelper(page).expectNoErrors();
  });
});

// =============================================================================
// Other
// =============================================================================

test.describe('Other Parent Pages', () => {
  test('portfolio loads', async ({ page }) => {
    await navigateTo(page, '/parent/portfolio');
    await new StateHelper(page).expectNoErrors();
  });

  test('calendar loads', async ({ page }) => {
    await navigateTo(page, '/parent/calendar');
    await new StateHelper(page).expectNoErrors();
  });
});
