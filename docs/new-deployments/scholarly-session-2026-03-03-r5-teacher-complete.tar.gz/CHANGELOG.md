# scholarly-session-2026-03-03-r5-teacher-complete.tar.gz

**Date:** 3 March 2026
**Session:** R5 Teacher Module — ALL 33 Pages Complete
**Total files:** 35 (33 pages + teacher-api.ts + use-teacher.ts)
**Total lines:** 4,110

## Design Principle: Zero Hardcoded Data

Every page in this delivery gets every data point from a real backend endpoint. No mocks, no stubs, no fallback arrays, no DEMO_MODE. When the backend runs, pages display live data. When it doesn't, pages show loading skeletons then error states.

## R3 Infrastructure

| File | Lines | Description |
|------|-------|-------------|
| lib/teacher-api.ts | 385L | Production API client, 10 namespaces, ~55 endpoints. Path fixes: /ml not /ml-pipeline, /standards not /standards-compliance |
| hooks/use-teacher.ts | 90L | Parallel data fetcher: summary + platformStats + analytics + sessions + AI insights via Promise.allSettled |

## All 33 Pages by Batch

### Batch 1: Dashboard Core (4 pages)
| Page | Lines | Endpoints |
|------|-------|-----------|
| dashboard | 489L | /dashboard/summary, /quick-stats, /activity, /notifications, /analytics/teacher/dashboard, /sessions, /ai-buddy/message |
| classes | 149L | /analytics/teacher/dashboard (classBreakdown), /sessions, AI insights |
| reports | 208L | /analytics/teacher/dashboard, /analytics/reports, POST /analytics/reports |
| settings | 642L | Form-based, AI Intelligence Settings first |

### Batch 2: Students (4 pages)
| Page | Lines | Endpoints |
|------|-------|-----------|
| students | 190L | /users?role=learner (paginated, searchable), AI at-risk overlay |
| students/[id] | 323L | /users/:id, /ai-engine/bkt/mastery/:id, /ml/features/:id, /bkt/predictions/:id, /wellbeing/check/:id, /ai-buddy/message |
| students/at-risk | 118L | /ai-engine/ml/at-risk (ML confidence, risk factors, severity) |
| attendance | 180L | /users?role=learner, /analytics/teacher/dashboard (classBreakdown) |

### Batch 3: Assessment (3 pages)
| Page | Lines | Endpoints |
|------|-------|-----------|
| assessment | 101L | /content?type=assessment |
| assessment/builder | 101L | POST /content, /ai-buddy/message |
| assessment/library | 73L | /content?type=assessment&status=published |

### Batch 4: Grading (4 pages)
| Page | Lines | Endpoints |
|------|-------|-----------|
| grading | 141L | /content?type=assessment, /ai-buddy/message, /analytics/teacher/dashboard |
| grading/gradebook | 18L | Redirect to /teacher/gradebook |
| grading/pitches | 68L | /content (filtered by type) |
| grading/portfolios | 71L | /content (filtered by type) |

### Batch 5: Lessons + Standards + Challenges (5 pages)
| Page | Lines | Endpoints |
|------|-------|-----------|
| lesson-planner | 160L | /curriculum/lesson-plans, /collaboration/lesson-plans, /ai-buddy/message |
| lessons/new | 95L | POST /curriculum/lesson-plans/generate, /ai-buddy/message |
| standards | 75L | /curriculum/standards |
| challenges | 57L | /content?type=activity |
| challenges/create | 84L | POST /content, /ai-buddy/message, /analytics classBreakdown for class selector |

### Batch 6: Scheduling (5 pages)
| Page | Lines | Endpoints |
|------|-------|-----------|
| scheduling | 68L | /sessions?upcoming=true |
| scheduling/timetable | 86L | /sessions (grid view by day/hour) |
| scheduling/relief | 74L | /relief/absences, /relief/predictions |
| scheduling/capacity | 70L | /relief/pools, /analytics/teacher/dashboard |
| scheduling/rooms | 47L | /sessions (today's schedule) |

### Batch 7: Reviews + ML + Misc (8 pages)
| Page | Lines | Endpoints |
|------|-------|-----------|
| reviews | 48L | /content (published items) |
| reviews/assignments | 37L | /content (draft items) |
| ml | 70L | /ml/models, AI insights summary |
| ml/models | 40L | /ml/models, POST /ml/models/:id/train |
| ml/predictions | 68L | /ml/students/:id/risk-prediction, AI insights |
| gradebook | 86L | /users?role=learner, /analytics classBreakdown, AI at-risk overlay |
| journeys | 41L | /content?type=resource |
| help-requests | 32L | /dashboard/notifications |

## AI Integration Summary

Every page calls `useTeacher()` → parallel fetch of domain data + AI insights.

AI surfaces across all pages:
- **LIS badges** (purple gradient cards) with confidence percentages
- **At-risk overlays** on student lists, gradebook, dashboard
- **Ask Issy** chat panels on dashboard, student detail, assessment builder, grading, lesson planner, challenges
- **ML model management** on ml/* pages
- **BKT mastery heatmaps** on student detail with per-skill probability bars
- **Wellbeing monitoring** on student detail with break recommendations
- **Relief predictions** on scheduling/relief with ML confidence scores

## Deployment

1. Copy all files to corresponding paths in `packages/web/src/`
2. This tarball SUPERSEDES the earlier `scholarly-session-2026-03-03-r5-teacher.tar.gz` (Batches 1-2 only)
3. No new dependencies
4. No Prisma migration
5. Backend must be running — zero fallback mode

## What This Completes

**Teacher R5: 33/33 pages wired. 100% complete.**
