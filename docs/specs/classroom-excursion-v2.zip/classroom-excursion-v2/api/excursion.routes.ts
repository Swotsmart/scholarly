/**
 * Excursion API Routes
 * 
 * Express routes for the Excursion Service. All routes require
 * authentication and tenant context.
 * 
 * @module IntelligenceMesh/ClassroomExcursion/API
 * @version 2.0.0
 */

import { Router, Request, Response, NextFunction } from 'express';
import { ExcursionService } from '../services/excursion.service';
import { ExcursionStatus, CheckInStatus, ConsentStatus } from '../types/classroom-excursion.types';

// ============================================================================
// TYPES
// ============================================================================

interface AuthenticatedRequest extends Request {
  user: {
    id: string;
    name: string;
    tenantId: string;
    schoolId: string;
    roles: string[];
  };
}

// ============================================================================
// MIDDLEWARE
// ============================================================================

const asyncHandler = (fn: (req: AuthenticatedRequest, res: Response, next: NextFunction) => Promise<any>) => 
  (req: Request, res: Response, next: NextFunction) => 
    Promise.resolve(fn(req as AuthenticatedRequest, res, next)).catch(next);

// ============================================================================
// ROUTES FACTORY
// ============================================================================

export function createExcursionRoutes(service: ExcursionService): Router {
  const router = Router();

  // ==========================================================================
  // EXCURSION CRUD
  // ==========================================================================

  /**
   * Create a new excursion
   * POST /excursions
   */
  router.post('/', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, schoolId, id: userId, name: userName } = req.user;
    
    const result = await service.createExcursion({
      ...req.body,
      tenantId,
      schoolId,
      createdBy: userId
    });

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.status(201).json(result.data);
  }));

  /**
   * Get excursion by ID
   * GET /excursions/:id
   */
  router.get('/:id', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId } = req.user;
    const { id } = req.params;

    const result = await service.getExcursion(tenantId, id);

    if (!result.success) {
      return res.status(404).json({ error: result.error });
    }

    res.json(result.data);
  }));

  /**
   * List excursions for school
   * GET /excursions
   */
  router.get('/', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, schoolId } = req.user;
    const { status, dateFrom, dateTo, leadTeacherId } = req.query;

    const filters: any = {};
    if (status) filters.status = (status as string).split(',') as ExcursionStatus[];
    if (dateFrom) filters.dateFrom = new Date(dateFrom as string);
    if (dateTo) filters.dateTo = new Date(dateTo as string);
    if (leadTeacherId) filters.leadTeacherId = leadTeacherId as string;

    const result = await service.listExcursions(tenantId, schoolId, filters);

    res.json(result.data);
  }));

  /**
   * Approve excursion
   * POST /excursions/:id/approve
   */
  router.post('/:id/approve', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, id: userId } = req.user;
    const { id } = req.params;

    const result = await service.approveExcursion(tenantId, id, userId);

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json(result.data);
  }));

  /**
   * Start excursion
   * POST /excursions/:id/start
   */
  router.post('/:id/start', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, id: userId } = req.user;
    const { id } = req.params;

    const result = await service.startExcursion(tenantId, id, userId);

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json(result.data);
  }));

  /**
   * Complete excursion
   * POST /excursions/:id/complete
   */
  router.post('/:id/complete', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, id: userId } = req.user;
    const { id } = req.params;

    const result = await service.completeExcursion(tenantId, id, userId);

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json(result.data);
  }));

  /**
   * Get excursion dashboard
   * GET /excursions/:id/dashboard
   */
  router.get('/:id/dashboard', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId } = req.user;
    const { id } = req.params;

    const result = await service.getExcursionDashboard(tenantId, id);

    if (!result.success) {
      return res.status(404).json({ error: result.error });
    }

    res.json(result.data);
  }));

  // ==========================================================================
  // STUDENTS
  // ==========================================================================

  /**
   * Get students on excursion
   * GET /excursions/:id/students
   */
  router.get('/:id/students', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId } = req.user;
    const { id } = req.params;

    const result = await service.getExcursionStudents(tenantId, id);

    res.json(result.data);
  }));

  /**
   * Add students to excursion
   * POST /excursions/:id/students
   */
  router.post('/:id/students', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, id: userId } = req.user;
    const { id } = req.params;
    const { students } = req.body;

    const result = await service.addStudentsToExcursion(tenantId, id, students, userId);

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.status(201).json(result.data);
  }));

  /**
   * Update student consent
   * PUT /excursions/:excursionId/students/:studentId/consent
   */
  router.put('/:excursionId/students/:studentId/consent', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, id: userId } = req.user;
    const { excursionId, studentId } = req.params;
    const { status } = req.body;

    const result = await service.updateStudentConsent(
      tenantId, 
      excursionId, 
      studentId, 
      status as ConsentStatus, 
      userId
    );

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json(result.data);
  }));

  // ==========================================================================
  // CHECKPOINTS
  // ==========================================================================

  /**
   * Get checkpoints for excursion
   * GET /excursions/:id/checkpoints
   */
  router.get('/:id/checkpoints', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId } = req.user;
    const { id } = req.params;

    const result = await service.getCheckpoints(tenantId, id);

    res.json(result.data);
  }));

  /**
   * Create checkpoint
   * POST /excursions/:id/checkpoints
   */
  router.post('/:id/checkpoints', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, id: userId } = req.user;
    const { id } = req.params;

    const result = await service.createCheckpoint(tenantId, id, req.body, userId);

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.status(201).json(result.data);
  }));

  /**
   * Complete checkpoint
   * POST /excursions/:excursionId/checkpoints/:checkpointId/complete
   */
  router.post('/:excursionId/checkpoints/:checkpointId/complete', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, id: userId } = req.user;
    const { excursionId, checkpointId } = req.params;
    const { notes } = req.body;

    const result = await service.completeCheckpoint(tenantId, excursionId, checkpointId, userId, notes);

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json(result.data);
  }));

  // ==========================================================================
  // CHECK-INS (SAFETY CRITICAL)
  // ==========================================================================

  /**
   * Check in a student
   * POST /excursions/:id/check-ins
   */
  router.post('/:id/check-ins', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, id: userId } = req.user;
    const { id: excursionId } = req.params;
    const { checkpointId, studentId, status, method, location, notes } = req.body;

    const result = await service.checkInStudent({
      tenantId,
      excursionId,
      checkpointId,
      studentId,
      status: status as CheckInStatus,
      checkedBy: userId,
      method,
      location,
      notes
    });

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.status(201).json(result.data);
  }));

  /**
   * Bulk check-in students
   * POST /excursions/:id/check-ins/bulk
   */
  router.post('/:id/check-ins/bulk', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, id: userId } = req.user;
    const { id: excursionId } = req.params;
    const { checkpointId, checkIns, method, location } = req.body;

    const result = await service.bulkCheckIn({
      tenantId,
      excursionId,
      checkpointId,
      checkIns,
      checkedBy: userId,
      method,
      location
    });

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.status(201).json(result.data);
  }));

  /**
   * Mark student as found
   * POST /excursions/:excursionId/students/:studentId/found
   */
  router.post('/:excursionId/students/:studentId/found', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, id: userId } = req.user;
    const { excursionId, studentId } = req.params;
    const { location, notes } = req.body;

    const result = await service.markStudentFound(
      tenantId,
      excursionId,
      studentId,
      userId,
      location,
      notes
    );

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json(result.data);
  }));

  /**
   * Perform head count
   * POST /excursions/:id/head-count
   */
  router.post('/:id/head-count', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, id: userId } = req.user;
    const { id: excursionId } = req.params;
    const { actualCount, location } = req.body;

    const result = await service.performHeadCount(
      tenantId,
      excursionId,
      actualCount,
      location,
      userId
    );

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json(result.data);
  }));

  // ==========================================================================
  // ALERTS
  // ==========================================================================

  /**
   * Send missing student alert (from offline sync)
   * POST /excursions/:id/alerts
   */
  router.post('/:id/alerts', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
    const { tenantId, id: userId, name: userName } = req.user;
    const { id: excursionId } = req.params;
    const { checkpointId, studentIds, location, reportedBy } = req.body;

    await service.sendMissingStudentAlert({
      tenantId,
      excursionId,
      checkpointId,
      studentIds,
      reportedBy: reportedBy || userName,
      location
    });

    res.status(202).json({ message: 'Alert sent' });
  }));

  return router;
}

export default createExcursionRoutes;
