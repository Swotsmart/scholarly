/**
 * Discovery Capture Components
 * 
 * React components for the student outdoor discovery and capture app.
 * All components include proper error handling and Tailwind CSS styling.
 * 
 * @module IntelligenceMesh/ClassroomExcursion/Discovery
 * @version 2.0.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { OfflineExcursionManager } from '../offline/offline-excursion-manager';
import { CaptureType, GeoLocation, TaskStatus, SyncStatus } from '../types/classroom-excursion.types';
import { LocalTask } from '../offline/offline-database';

// ============================================================================
// HOOKS
// ============================================================================

export function useOfflineExcursion(manager: OfflineExcursionManager, excursionId: string) {
  const [isOnline, setIsOnline] = useState(manager.isOnline());
  const [syncStatus, setSyncStatus] = useState<{
    pendingCount: number;
    criticalPending: number;
    failedCriticalAlerts: number;
    lastSync: string | null;
  }>({ pendingCount: 0, criticalPending: 0, failedCriticalAlerts: 0, lastSync: null });
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    const unsubConnectivity = manager.on('connectivityChange', ({ online }: { online: boolean }) => setIsOnline(online));
    const unsubProgress = manager.on('syncProgress', (progress: any) => setIsSyncing(progress.phase !== 'complete' && progress.phase !== 'error'));

    const pollStatus = async () => {
      const status = await manager.getSyncStatus();
      setSyncStatus({ pendingCount: status.pendingCount, criticalPending: status.criticalPending, failedCriticalAlerts: status.failedCriticalAlerts, lastSync: status.lastSync });
    };

    pollStatus();
    const interval = setInterval(pollStatus, 5000);
    return () => { unsubConnectivity(); unsubProgress(); clearInterval(interval); };
  }, [manager]);

  return { isOnline, syncStatus, isSyncing };
}

export function useGeolocation() {
  const [location, setLocation] = useState<GeoLocation | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const getLocation = useCallback(() => {
    if (!navigator.geolocation) { setError('Geolocation not supported'); return; }
    setLoading(true);
    setError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => { setLocation({ latitude: pos.coords.latitude, longitude: pos.coords.longitude, accuracy: pos.coords.accuracy }); setLoading(false); },
      (err) => {
        const msg = err.code === err.PERMISSION_DENIED ? 'Location permission denied' : err.code === err.POSITION_UNAVAILABLE ? 'Location unavailable' : 'Location timeout';
        setError(msg);
        setLoading(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }, []);

  return { location, error, loading, getLocation, clearError: () => setError(null) };
}

// ============================================================================
// COMPONENTS
// ============================================================================

export const ErrorMessage: React.FC<{ message: string; onDismiss?: () => void }> = ({ message, onDismiss }) => (
  <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4 flex items-start gap-3">
    <svg className="w-5 h-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
    <p className="flex-1 text-sm text-red-700">{message}</p>
    {onDismiss && <button onClick={onDismiss} className="text-red-500 hover:text-red-700">✕</button>}
  </div>
);

export const SyncStatusIndicator: React.FC<{
  isOnline: boolean;
  pendingCount: number;
  criticalPending: number;
  failedCriticalAlerts?: number;
  isSyncing: boolean;
  onForceSync: () => void;
}> = ({ isOnline, pendingCount, criticalPending, failedCriticalAlerts = 0, isSyncing, onForceSync }) => (
  <div className={`flex items-center gap-3 px-4 py-2 rounded-full text-sm ${isOnline ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
    <span className={`w-2.5 h-2.5 rounded-full ${isOnline ? 'bg-green-500' : 'bg-amber-500 animate-pulse'}`} />
    <span className="font-medium">{isOnline ? 'Online' : 'Offline'}</span>
    {criticalPending > 0 && <span className="bg-red-500 text-white px-2 py-0.5 rounded-full text-xs font-bold animate-pulse">{criticalPending} critical!</span>}
    {failedCriticalAlerts > 0 && <span className="bg-red-700 text-white px-2 py-0.5 rounded-full text-xs font-bold">{failedCriticalAlerts} failed</span>}
    {pendingCount > 0 && criticalPending === 0 && <span className="text-gray-600">{pendingCount} pending</span>}
    {isSyncing && <span className="text-blue-600">Syncing...</span>}
    {isOnline && pendingCount > 0 && !isSyncing && <button onClick={onForceSync} className="px-3 py-1 bg-blue-600 text-white rounded-full text-xs hover:bg-blue-700">Sync</button>}
  </div>
);

export const PhotoCapture: React.FC<{ onCapture: (blob: Blob, location?: GeoLocation) => void; disabled?: boolean }> = ({ onCapture, disabled }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturing, setCapturing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { location, getLocation } = useGeolocation();

  const startCamera = async () => {
    setError(null);
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
      if (videoRef.current) { videoRef.current.srcObject = mediaStream; videoRef.current.play(); }
      setStream(mediaStream);
      setCapturing(true);
      getLocation();
    } catch (err: any) {
      setError(err.name === 'NotAllowedError' ? 'Camera permission denied' : err.name === 'NotFoundError' ? 'No camera found' : 'Camera error');
    }
  };

  const stopCamera = () => { stream?.getTracks().forEach(t => t.stop()); setStream(null); setCapturing(false); };

  const takePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const canvas = canvasRef.current;
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    canvas.getContext('2d')?.drawImage(videoRef.current, 0, 0);
    canvas.toBlob(blob => { if (blob) { onCapture(blob, location || undefined); stopCamera(); } }, 'image/jpeg', 0.85);
  };

  useEffect(() => () => { stream?.getTracks().forEach(t => t.stop()); }, [stream]);

  return (
    <div>
      {error && <ErrorMessage message={error} onDismiss={() => setError(null)} />}
      {!capturing ? (
        <button onClick={startCamera} disabled={disabled} className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 disabled:opacity-50">
          📷 Take Photo
        </button>
      ) : (
        <div className="relative bg-black rounded-xl overflow-hidden">
          <video ref={videoRef} playsInline autoPlay muted className="w-full max-h-96" />
          <canvas ref={canvasRef} className="hidden" />
          <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-4">
            <button onClick={stopCamera} className="p-3 bg-gray-700/80 text-white rounded-full">✕</button>
            <button onClick={takePhoto} className="p-4 bg-white rounded-full shadow-lg">📸</button>
          </div>
          {location && <div className="absolute top-4 left-4 px-3 py-1 bg-green-500/80 text-white rounded-full text-sm">📍 Location captured</div>}
        </div>
      )}
    </div>
  );
};

export const VoiceMemo: React.FC<{ onCapture: (blob: Blob, duration: number) => void; maxDuration?: number; disabled?: boolean }> = ({ onCapture, maxDuration = 120, disabled }) => {
  const [recording, setRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const startRecording = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      mediaRecorderRef.current = mr;
      chunksRef.current = [];
      mr.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      mr.onstop = () => { onCapture(new Blob(chunksRef.current, { type: 'audio/webm' }), duration); stream.getTracks().forEach(t => t.stop()); };
      mr.start();
      setRecording(true);
      setDuration(0);
      timerRef.current = setInterval(() => setDuration(d => { if (d >= maxDuration - 1) { stopRecording(); return d; } return d + 1; }), 1000);
    } catch (err: any) {
      setError(err.name === 'NotAllowedError' ? 'Microphone permission denied' : 'Microphone error');
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setRecording(false);
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
  };

  return (
    <div>
      {error && <ErrorMessage message={error} onDismiss={() => setError(null)} />}
      {!recording ? (
        <button onClick={startRecording} disabled={disabled} className="flex items-center gap-2 px-6 py-3 bg-red-600 text-white rounded-xl hover:bg-red-700 disabled:opacity-50">
          🎤 Record
        </button>
      ) : (
        <div className="flex items-center gap-4 p-4 bg-red-50 rounded-xl border border-red-200">
          <span className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
          <span className="font-mono">{Math.floor(duration / 60)}:{(duration % 60).toString().padStart(2, '0')}</span>
          <button onClick={stopRecording} className="px-4 py-2 bg-red-600 text-white rounded-lg">Stop</button>
        </div>
      )}
    </div>
  );
};

export const TextNote: React.FC<{ onSubmit: (text: string, tags: string[]) => void; suggestedTags?: string[]; disabled?: boolean }> = ({ onSubmit, suggestedTags = [], disabled }) => {
  const [text, setText] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');

  const addTag = (tag: string) => { if (tag && !tags.includes(tag)) setTags([...tags, tag]); setNewTag(''); };

  return (
    <div className="space-y-3">
      <textarea value={text} onChange={e => setText(e.target.value)} placeholder="Type your note..." disabled={disabled} rows={3} className="w-full px-4 py-3 border rounded-xl" />
      <div className="flex flex-wrap gap-2">
        {tags.map(t => <span key={t} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">{t} <button onClick={() => setTags(tags.filter(x => x !== t))}>×</button></span>)}
      </div>
      <div className="flex gap-2">
        <input value={newTag} onChange={e => setNewTag(e.target.value)} placeholder="Add tag" onKeyPress={e => e.key === 'Enter' && addTag(newTag)} className="flex-1 px-3 py-2 border rounded-lg text-sm" />
        <button onClick={() => addTag(newTag)} className="px-3 py-2 bg-gray-200 rounded-lg">+</button>
      </div>
      {suggestedTags.filter(t => !tags.includes(t)).length > 0 && (
        <div className="flex flex-wrap gap-1">
          {suggestedTags.filter(t => !tags.includes(t)).map(t => <button key={t} onClick={() => addTag(t)} className="px-2 py-1 text-xs bg-gray-100 rounded-full">+ {t}</button>)}
        </div>
      )}
      <button onClick={() => { if (text.trim()) { onSubmit(text.trim(), tags); setText(''); setTags([]); } }} disabled={disabled || !text.trim()} className="px-6 py-3 bg-green-600 text-white rounded-xl disabled:opacity-50">
        📝 Save Note
      </button>
    </div>
  );
};

export const TaskCard: React.FC<{ task: LocalTask; progress: { status: TaskStatus; capturesSubmitted: number }; onStartTask: () => void; onOpenTask: () => void }> = ({ task, progress, onStartTask, onOpenTask }) => {
  const total = task.requiredCaptures.reduce((s, r) => s + r.count, 0);
  const pct = Math.min((progress.capturesSubmitted / total) * 100, 100);

  return (
    <div className="rounded-xl border-2 p-4 bg-white">
      <div className="flex justify-between mb-2">
        <h3 className="font-semibold">{task.title}</h3>
        {task.points && <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs">{task.points} pts</span>}
      </div>
      <p className="text-sm text-gray-600 mb-3">{task.instructions}</p>
      <div className="flex flex-wrap gap-2 mb-3">
        {task.requiredCaptures.map((r, i) => <span key={i} className="px-2 py-1 bg-gray-100 rounded text-xs">{r.count}× {r.type}</span>)}
      </div>
      <div className="mb-4">
        <div className="h-2 bg-gray-200 rounded-full"><div className="h-full bg-blue-600 rounded-full" style={{ width: `${pct}%` }} /></div>
        <div className="text-xs text-gray-500 mt-1">{progress.capturesSubmitted} / {total}</div>
      </div>
      {progress.status === TaskStatus.NOT_STARTED ? (
        <button onClick={onStartTask} className="w-full py-2 bg-blue-600 text-white rounded-lg">Start</button>
      ) : progress.status === TaskStatus.IN_PROGRESS ? (
        <button onClick={onOpenTask} className="w-full py-2 bg-blue-100 text-blue-700 rounded-lg">Continue</button>
      ) : (
        <span className="block text-center py-2 bg-green-100 text-green-700 rounded-lg text-sm">{progress.status}</span>
      )}
    </div>
  );
};

export const DiscoveryApp: React.FC<{ manager: OfflineExcursionManager; excursionId: string; studentId: string; studentName: string }> = ({ manager, excursionId, studentId, studentName }) => {
  const { isOnline, syncStatus, isSyncing } = useOfflineExcursion(manager, excursionId);
  const [tasks, setTasks] = useState<LocalTask[]>([]);
  const [selectedTask, setSelectedTask] = useState<LocalTask | null>(null);
  const [captures, setCaptures] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { location, getLocation } = useGeolocation();

  useEffect(() => { manager.getTasks(excursionId).then(t => { setTasks(t); setLoading(false); }); getLocation(); }, [excursionId]);

  const loadCaptures = async (taskId: string) => setCaptures(await manager.getCapturesForTask(excursionId, taskId));

  const handleCapture = async (type: CaptureType, data: any) => {
    if (!selectedTask) return;
    await manager.submitCapture(excursionId, selectedTask.taskId, studentId, type, { ...data, location: data.location || location });
    loadCaptures(selectedTask.taskId);
  };

  if (loading) return <div className="flex justify-center p-8"><div className="animate-spin h-12 w-12 border-4 border-blue-600 border-t-transparent rounded-full" /></div>;

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-6">
      <header className="flex flex-wrap items-center justify-between gap-4">
        <div><h1 className="text-2xl font-bold">Discovery Tasks</h1><p className="text-gray-600">{studentName}</p></div>
        <SyncStatusIndicator isOnline={isOnline} pendingCount={syncStatus.pendingCount} criticalPending={syncStatus.criticalPending} failedCriticalAlerts={syncStatus.failedCriticalAlerts} isSyncing={isSyncing} onForceSync={() => manager.forceSync()} />
      </header>

      {!selectedTask ? (
        <div className="grid gap-4 sm:grid-cols-2">
          {tasks.map(task => <TaskCard key={task.taskId} task={task} progress={{ status: TaskStatus.NOT_STARTED, capturesSubmitted: 0 }} onStartTask={() => { setSelectedTask(task); loadCaptures(task.taskId); }} onOpenTask={() => { setSelectedTask(task); loadCaptures(task.taskId); }} />)}
          {tasks.length === 0 && <p className="col-span-2 text-center text-gray-500 py-8">No tasks available.</p>}
        </div>
      ) : (
        <div className="space-y-6">
          <button onClick={() => setSelectedTask(null)} className="text-blue-600">← Back</button>
          <div className="bg-white rounded-xl shadow p-6">
            <h2 className="text-xl font-semibold mb-2">{selectedTask.title}</h2>
            <p className="text-gray-600 mb-6">{selectedTask.instructions}</p>
            <div className="space-y-4">
              <PhotoCapture onCapture={(blob, loc) => handleCapture(CaptureType.PHOTO, { mediaBlob: blob, location: loc })} />
              <VoiceMemo onCapture={(blob) => handleCapture(CaptureType.VOICE_MEMO, { mediaBlob: blob })} />
              <TextNote onSubmit={(text, tags) => handleCapture(CaptureType.TEXT_NOTE, { textContent: text, tags })} suggestedTags={selectedTask.curriculumCodes} />
            </div>
          </div>
          <div className="bg-white rounded-xl shadow p-6">
            <h3 className="font-medium mb-4">Your Captures ({captures.length})</h3>
            {captures.length > 0 ? captures.map(c => (
              <div key={c.localId} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg mb-2">
                <span>{c.type === CaptureType.PHOTO ? '📷' : c.type === CaptureType.VOICE_MEMO ? '🎤' : '📝'} {c.type}</span>
                <span className={`px-2 py-1 rounded-full text-xs ${c.syncStatus === SyncStatus.SYNCED ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                  {c.syncStatus === SyncStatus.SYNCED ? '✓' : '⏳'}
                </span>
              </div>
            )) : <p className="text-gray-500 text-center">No captures yet.</p>}
          </div>
        </div>
      )}
    </div>
  );
};

export default DiscoveryApp;
