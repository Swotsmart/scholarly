/**
 * Classroom & Excursion Module
 * 
 * Extends the Intelligence Mesh with:
 * - AI-Assisted Roll Call
 * - Dynamic Seating Arrangements
 * - Real-Time Help Requests
 * - Offline-Capable Excursion Management
 * - Outdoor Discovery & Capture
 * - Lesson Feedback & School Pulse
 * 
 * @module IntelligenceMesh/ClassroomExcursion
 * @version 2.0.0
 */

// Types
export * from './types/classroom-excursion.types';

// Offline Layer
export { 
  OfflineDatabase, 
  STORES,
  DB_NAME,
  DB_VERSION,
  generateLocalId,
  generateOrderedId,
  createLocalRecord,
  type LocalExcursion,
  type LocalStudent,
  type LocalCheckIn,
  type LocalCapture,
  type LocalCheckpoint,
  type LocalTask
} from './offline/offline-database';

export {
  SyncEngine,
  ConnectivityMonitor,
  PreflightLoader,
  type SyncConfig,
  type SyncResult,
  type SyncProgress,
  type SyncProgressCallback,
  type ConnectivityCallback,
  type CriticalAlertFailedCallback
} from './offline/sync-engine';

export {
  OfflineExcursionManager,
  type OfflineManagerConfig,
  type CheckInResult,
  type CaptureResult,
  type MissingStudentAlert
} from './offline/offline-excursion-manager';

// Server-side Services
export {
  ExcursionService,
  type ExcursionRepository,
  type ExcursionStudentRepository,
  type CheckpointRepository,
  type CheckInRepository,
  type ExcursionFilters,
  type CreateExcursionInput,
  type CheckInInput,
  type BulkCheckInInput,
  type MissingStudentAlertInput,
  type EventBus,
  type NotificationService
} from './services/excursion.service';

// API Routes
export { createExcursionRoutes } from './api/excursion.routes';

// React Components (client-side only)
export {
  useOfflineExcursion,
  useGeolocation,
  ErrorMessage,
  SyncStatusIndicator,
  PhotoCapture,
  VoiceMemo,
  TextNote,
  TaskCard,
  DiscoveryApp
} from './discovery/discovery-components';
