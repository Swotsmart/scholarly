/**
 * Offline Excursion Manager
 * 
 * The primary client-side API for offline-first excursion management.
 * Provides a clean interface for the UI to perform excursion operations
 * that work seamlessly whether online or offline.
 * 
 * @module IntelligenceMesh/ClassroomExcursion/Offline
 * @version 2.0.0
 */

import {
  OfflineDatabase, STORES, generateLocalId, createLocalRecord,
  LocalExcursion, LocalStudent, LocalCheckIn, LocalCapture, LocalCheckpoint, LocalTask
} from './offline-database';
import { SyncEngine, ConnectivityMonitor, PreflightLoader, SyncProgress, SyncResult, SyncConfig } from './sync-engine';
import {
  SyncStatus, SyncPriority, CheckInStatus, CaptureType, GeoLocation,
  CLASSROOM_EXCURSION_EVENTS, SyncQueueItem
} from '../types/classroom-excursion.types';

// ============================================================================
// TYPES
// ============================================================================

export interface OfflineManagerConfig {
  apiBaseUrl: string;
  getAuthToken: () => Promise<string>;
  tenantId: string;
  schoolId: string;
  userId: string;
  userName: string;
  syncIntervalMs?: number;
  enableSMSFallback?: boolean;
  smsGatewayUrl?: string;
  getSmsAuthToken?: () => Promise<string>;
  emergencyContacts?: string[];
  healthCheckUrl?: string;
}

export interface CheckInResult {
  success: boolean;
  localId: string;
  syncStatus: SyncStatus;
  studentStatus: CheckInStatus;
}

export interface CaptureResult {
  success: boolean;
  localId: string;
  syncStatus: SyncStatus;
}

export interface MissingStudentAlert {
  excursionId: string;
  checkpointId: string;
  checkpointName: string;
  studentIds: string[];
  studentNames: string[];
  reportedBy: string;
  reportedAt: Date;
  location?: GeoLocation;
}

// ============================================================================
// EVENT EMITTER
// ============================================================================

type EventCallback = (data: any) => void;

class EventEmitter {
  private listeners: Map<string, Set<EventCallback>> = new Map();

  on(event: string, callback: EventCallback): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);
    return () => this.off(event, callback);
  }

  off(event: string, callback: EventCallback): void {
    this.listeners.get(event)?.delete(callback);
  }

  emit(event: string, data: any): void {
    this.listeners.get(event)?.forEach(cb => {
      try {
        cb(data);
      } catch (e) {
        console.error(`Error in event handler for ${event}:`, e);
      }
    });
  }
}

// ============================================================================
// OFFLINE EXCURSION MANAGER
// ============================================================================

export class OfflineExcursionManager extends EventEmitter {
  private db: OfflineDatabase;
  private syncEngine: SyncEngine;
  private connectivity: ConnectivityMonitor;
  private preflight: PreflightLoader;
  private config: OfflineManagerConfig;
  private initialized: boolean = false;

  constructor(config: OfflineManagerConfig) {
    super();
    this.config = config;
    
    this.db = new OfflineDatabase();
    this.connectivity = new ConnectivityMonitor(
      config.healthCheckUrl || `${config.apiBaseUrl}/health`
    );
    
    const syncConfig: SyncConfig = {
      apiBaseUrl: config.apiBaseUrl,
      getAuthToken: config.getAuthToken,
      tenantId: config.tenantId,
      maxConcurrentUploads: 3,
      syncIntervalMs: config.syncIntervalMs || 30000,
      maxRetries: 5,
      baseRetryDelayMs: 1000,
      maxRetryDelayMs: 30000,
      mediaChunkSize: 1024 * 1024,
      enableSMSFallback: config.enableSMSFallback || false,
      smsGatewayUrl: config.smsGatewayUrl,
      getSmsAuthToken: config.getSmsAuthToken,
      emergencyContacts: config.emergencyContacts
    };
    
    this.syncEngine = new SyncEngine(this.db, syncConfig, this.connectivity);
    this.preflight = new PreflightLoader(this.db, syncConfig);
  }

  /**
   * Initialize the manager
   */
  async initialize(): Promise<void> {
    if (this.initialized) return;
    
    await this.db.initialize();
    
    // Set up event forwarding from sync engine
    this.syncEngine.setEventEmitter((event, data) => this.emit(event, data));
    
    // Set up sync progress events
    this.syncEngine.onProgress((progress) => {
      this.emit('syncProgress', progress);
    });
    
    // Set up critical alert failed callback
    this.syncEngine.onCriticalAlertFailed((alert, error) => {
      this.emit('criticalAlertFailed', { alert, error });
    });
    
    // Set up connectivity events
    this.connectivity.subscribe((online) => {
      this.emit('connectivityChange', { online });
    });
    
    // Start auto-sync
    this.syncEngine.startAutoSync();
    
    // Start periodic connectivity checks
    this.connectivity.startPeriodicChecks();
    
    this.initialized = true;
    console.log('[OfflineExcursionManager] Initialized');
  }

  // ==========================================================================
  // PREFLIGHT
  // ==========================================================================

  async preloadExcursion(
    excursionId: string,
    onProgress?: (phase: string, progress: number) => void
  ): Promise<{ success: boolean; error?: string }> {
    return this.preflight.loadExcursionData(excursionId, onProgress);
  }

  async isExcursionReady(excursionId: string): Promise<boolean> {
    return this.preflight.isExcursionCached(excursionId);
  }

  // ==========================================================================
  // DATA ACCESS
  // ==========================================================================

  async getExcursion(excursionId: string): Promise<LocalExcursion | null> {
    const results = await this.db.queryByIndex<LocalExcursion>(STORES.EXCURSIONS, 'by_excursion_id', excursionId);
    return results[0] || null;
  }

  async getStudents(excursionId: string): Promise<LocalStudent[]> {
    return this.db.queryByIndex<LocalStudent>(STORES.STUDENTS, 'by_excursion', excursionId);
  }

  async getStudent(excursionId: string, studentId: string): Promise<LocalStudent | null> {
    const results = await this.db.queryByIndex<LocalStudent>(STORES.STUDENTS, 'by_student', [excursionId, studentId]);
    return results[0] || null;
  }

  async getCheckpoints(excursionId: string): Promise<LocalCheckpoint[]> {
    return this.db.queryByIndex<LocalCheckpoint>(STORES.CHECKPOINTS, 'by_excursion', excursionId);
  }

  async getTasks(excursionId: string): Promise<LocalTask[]> {
    return this.db.queryByIndex<LocalTask>(STORES.TASKS, 'by_excursion', excursionId);
  }

  // ==========================================================================
  // CHECK-IN OPERATIONS
  // ==========================================================================

  async checkInStudent(
    excursionId: string,
    checkpointId: string,
    checkpointName: string,
    studentId: string,
    studentName: string,
    status: CheckInStatus,
    options?: {
      method?: 'manual' | 'qr_scan' | 'geofence' | 'nfc';
      location?: GeoLocation;
      notes?: string;
    }
  ): Promise<CheckInResult> {
    const localId = generateLocalId();
    const now = new Date();
    
    const checkIn: LocalCheckIn = createLocalRecord({
      excursionId,
      checkpointId,
      checkpointName,
      studentId,
      studentName,
      status,
      checkedAt: now,
      checkedBy: this.config.userId,
      checkedByName: this.config.userName,
      method: options?.method || 'manual',
      location: options?.location,
      notes: options?.notes
    }) as LocalCheckIn;
    
    await this.db.put(STORES.CHECK_INS, checkIn);
    
    // Update student status
    const student = await this.getStudent(excursionId, studentId);
    if (student) {
      await this.db.put(STORES.STUDENTS, {
        ...student,
        checkInStatus: status,
        lastLocation: options?.location ? { ...options.location, timestamp: now } : student.lastLocation
      });
    }
    
    // Queue for sync with appropriate priority
    const priority = status === CheckInStatus.MISSING ? SyncPriority.CRITICAL : SyncPriority.HIGH;
    
    await this.db.queueForSync({
      type: 'check_in',
      priority,
      entityType: 'check_in',
      entityId: localId,
      payload: checkIn,
      maxRetries: status === CheckInStatus.MISSING ? 10 : 5
    });
    
    // Emit event
    if (status === CheckInStatus.MISSING) {
      this.emit(CLASSROOM_EXCURSION_EVENTS.STUDENTS_MISSING, {
        excursionId,
        checkpointId,
        checkpointName,
        studentIds: [studentId],
        studentNames: [studentName],
        reportedBy: this.config.userName,
        reportedAt: now,
        location: options?.location
      });
      
      // Trigger immediate sync for missing student
      if (this.connectivity.isOnline()) {
        this.syncEngine.forceSync();
      }
    }
    
    return {
      success: true,
      localId,
      syncStatus: SyncStatus.PENDING,
      studentStatus: status
    };
  }

  async markStudentMissing(
    excursionId: string,
    checkpointId: string,
    checkpointName: string,
    studentId: string,
    studentName: string,
    location?: GeoLocation
  ): Promise<CheckInResult> {
    return this.checkInStudent(
      excursionId,
      checkpointId,
      checkpointName,
      studentId,
      studentName,
      CheckInStatus.MISSING,
      { location, notes: 'MISSING - Requires immediate attention' }
    );
  }

  async markStudentFound(
    excursionId: string,
    studentId: string,
    studentName: string,
    location?: GeoLocation,
    notes?: string
  ): Promise<CheckInResult> {
    const student = await this.getStudent(excursionId, studentId);
    const checkpointId = student?.lastCheckIn?.checkpointId || 'found_location';
    const checkpointName = student?.lastCheckIn?.checkpointName || 'Found Location';
    
    const result = await this.checkInStudent(
      excursionId,
      checkpointId,
      checkpointName,
      studentId,
      studentName,
      CheckInStatus.AT_DESTINATION,
      { location, notes: notes || 'Student found and safe' }
    );
    
    this.emit(CLASSROOM_EXCURSION_EVENTS.STUDENT_FOUND, {
      excursionId,
      studentId,
      studentName,
      foundAt: new Date(),
      foundBy: this.config.userName,
      location
    });
    
    return result;
  }

  async bulkCheckIn(
    excursionId: string,
    checkpointId: string,
    checkpointName: string,
    checkIns: { studentId: string; studentName: string; status: CheckInStatus }[],
    location?: GeoLocation
  ): Promise<{ success: boolean; presentCount: number; missingStudents: string[]; missingNames: string[] }> {
    const missingStudents: string[] = [];
    const missingNames: string[] = [];
    
    for (const checkIn of checkIns) {
      await this.checkInStudent(excursionId, checkpointId, checkpointName, checkIn.studentId, checkIn.studentName, checkIn.status, { location });
      if (checkIn.status === CheckInStatus.MISSING) {
        missingStudents.push(checkIn.studentId);
        missingNames.push(checkIn.studentName);
      }
    }
    
    // Bulk missing alert
    if (missingStudents.length > 0) {
      const alertId = generateLocalId();
      const alert: MissingStudentAlert = {
        excursionId,
        checkpointId,
        checkpointName,
        studentIds: missingStudents,
        studentNames: missingNames,
        reportedBy: this.config.userName,
        reportedAt: new Date(),
        location
      };
      
      await this.db.queueForSync({
        type: 'alert',
        priority: SyncPriority.CRITICAL,
        entityType: 'missing_alert',
        entityId: alertId,
        payload: alert,
        maxRetries: 10
      });
      
      this.emit(CLASSROOM_EXCURSION_EVENTS.STUDENTS_MISSING, alert);
      
      if (this.connectivity.isOnline()) {
        this.syncEngine.forceSync();
      }
    }
    
    const presentCount = checkIns.filter(c => c.status !== CheckInStatus.MISSING && c.status !== CheckInStatus.NOT_CHECKED_IN).length;
    
    return { success: true, presentCount, missingStudents, missingNames };
  }

  async quickHeadCount(excursionId: string, actualCount: number, location?: GeoLocation): Promise<{ expectedCount: number; actualCount: number; discrepancy: number; alert: boolean }> {
    const students = await this.getStudents(excursionId);
    const expectedCount = students.filter(s => s.checkInStatus !== CheckInStatus.EARLY_DEPARTURE).length;
    const discrepancy = expectedCount - actualCount;
    const alert = discrepancy !== 0;
    
    if (alert) {
      this.emit(CLASSROOM_EXCURSION_EVENTS.HEAD_COUNT_DISCREPANCY, { excursionId, expectedCount, actualCount, discrepancy, location, reportedBy: this.config.userName });
    }
    
    return { expectedCount, actualCount, discrepancy, alert };
  }

  // ==========================================================================
  // CAPTURE OPERATIONS
  // ==========================================================================

  async submitCapture(
    excursionId: string,
    taskId: string,
    studentId: string,
    type: CaptureType,
    data: {
      mediaBlob?: Blob;
      textContent?: string;
      caption?: string;
      tags?: string[];
      location?: GeoLocation;
      sensorData?: { sensorType: string; value: number; unit: string };
    }
  ): Promise<CaptureResult> {
    const localId = generateLocalId();
    const now = new Date();
    
    let mediaBlobId: string | undefined;
    if (data.mediaBlob) {
      mediaBlobId = `media_${localId}`;
      await this.db.storeMedia(mediaBlobId, data.mediaBlob);
    }
    
    const capture: LocalCapture = createLocalRecord({
      excursionId,
      taskId,
      studentId,
      participantType: 'student',
      participantId: studentId,
      type,
      mediaBlobId,
      mediaSize: data.mediaBlob?.size,
      mediaMimeType: data.mediaBlob?.type,
      textContent: data.textContent,
      caption: data.caption,
      tags: data.tags,
      location: data.location,
      capturedAt: now,
      sensorData: data.sensorData
    }) as LocalCapture;
    
    await this.db.put(STORES.CAPTURES, capture);
    
    await this.db.queueForSync({
      type: 'capture',
      priority: SyncPriority.NORMAL,
      entityType: 'capture',
      entityId: localId,
      payload: { ...capture, mediaBlobId },
      maxRetries: 3
    });
    
    this.emit(CLASSROOM_EXCURSION_EVENTS.CAPTURE_SUBMITTED, { excursionId, taskId, studentId, type, localId });
    
    return { success: true, localId, syncStatus: SyncStatus.PENDING };
  }

  async getCapturesForTask(excursionId: string, taskId: string): Promise<LocalCapture[]> {
    return this.db.queryByIndex<LocalCapture>(STORES.CAPTURES, 'by_task', [excursionId, taskId]);
  }

  async getCaptureMedia(mediaBlobId: string): Promise<Blob | null> {
    return this.db.getMedia(mediaBlobId);
  }

  // ==========================================================================
  // SYNC STATUS
  // ==========================================================================

  async getSyncStatus(): Promise<{
    isOnline: boolean;
    isSyncing: boolean;
    lastSync: string | null;
    pendingCount: number;
    criticalPending: number;
    failedCriticalAlerts: number;
    queueBreakdown: Record<string, number>;
  }> {
    const status = await this.syncEngine.getSyncStatus();
    const queueCount = await this.db.getSyncQueueCount();
    return { ...status, queueBreakdown: queueCount.byPriority };
  }

  async forceSync(): Promise<SyncResult> {
    return this.syncEngine.forceSync();
  }

  isOnline(): boolean {
    return this.connectivity.isOnline();
  }

  async getStorageUsage(): Promise<{ used: number; available: number; percentage: number; mediaUsed: number }> {
    const estimate = await this.db.getStorageEstimate();
    const mediaUsed = await this.db.getMediaStorageUsed();
    return { ...estimate, mediaUsed };
  }

  async getFailedCriticalAlerts(): Promise<any[]> {
    return this.db.getUnresolvedFailedAlerts();
  }

  async resolveFailedAlert(id: string, notes: string): Promise<void> {
    await this.db.resolveFailedAlert(id, this.config.userId, notes);
  }

  // ==========================================================================
  // CLEANUP
  // ==========================================================================

  async clearExcursionData(excursionId: string): Promise<void> {
    await this.preflight.clearExcursionCache(excursionId);
  }

  destroy(): void {
    this.syncEngine.destroy();
    this.connectivity.stopPeriodicChecks();
    this.db.close();
  }
}
