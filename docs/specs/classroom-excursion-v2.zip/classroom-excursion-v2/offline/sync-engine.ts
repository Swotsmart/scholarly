/**
 * Sync Engine
 * 
 * Handles bidirectional synchronization between local IndexedDB and server
 * with priority-based ordering ensuring safety-critical data syncs first.
 * 
 * ## Priority System
 * 
 * When connectivity returns, syncing happens in strict priority order:
 * 
 * 1. CRITICAL (100): Missing student alerts, SOS signals
 *    - These MUST go through immediately
 *    - Will retry aggressively
 *    - Triggers SMS fallback if API fails
 * 
 * 2. HIGH (75): Check-ins, attendance records
 *    - Safety-related but not emergency
 *    - Retry with backoff
 * 
 * 3. NORMAL (50): Captures, task progress, feedback
 *    - Educational data
 *    - Can wait if bandwidth limited
 * 
 * 4. LOW (25): Analytics, non-essential updates
 *    - Nice to have
 *    - Can be deferred
 * 
 * @module IntelligenceMesh/ClassroomExcursion/Offline
 * @version 2.0.0
 */

import {
  OfflineDatabase, STORES, generateLocalId
} from './offline-database';
import {
  SyncStatus, SyncPriority, SyncQueueItem, ConflictRecord,
  CLASSROOM_EXCURSION_EVENTS
} from '../types/classroom-excursion.types';

// ============================================================================
// TYPES
// ============================================================================

export interface SyncConfig {
  apiBaseUrl: string;
  getAuthToken: () => Promise<string>;
  tenantId: string;
  maxConcurrentUploads: number;
  syncIntervalMs: number;
  maxRetries: number;
  baseRetryDelayMs: number;
  maxRetryDelayMs: number;
  mediaChunkSize: number;
  enableSMSFallback: boolean;
  smsGatewayUrl?: string;
  getSmsAuthToken?: () => Promise<string>;
  emergencyContacts?: string[];
}

export interface SyncResult {
  success: boolean;
  uploaded: number;
  downloaded: number;
  failed: number;
  conflicts: number;
  criticalPending: number;
  criticalFailed: number;
  duration: number;
  errors: string[];
}

export interface SyncProgress {
  phase: 'preparing' | 'uploading_critical' | 'uploading_high' | 'uploading_normal' | 'uploading_low' | 'downloading' | 'resolving_conflicts' | 'complete' | 'error';
  total: number;
  completed: number;
  currentItem?: string;
  currentPriority?: SyncPriority;
}

export type SyncProgressCallback = (progress: SyncProgress) => void;
export type ConnectivityCallback = (online: boolean) => void;
export type CriticalAlertFailedCallback = (alert: SyncQueueItem, error: string) => void;

// ============================================================================
// CONNECTIVITY MONITOR
// ============================================================================

export class ConnectivityMonitor {
  private online: boolean = typeof navigator !== 'undefined' ? navigator.onLine : true;
  private serverReachable: boolean = false;
  private listeners: Set<ConnectivityCallback> = new Set();
  private checkUrl: string;
  private checkInterval: number | null = null;

  constructor(checkUrl: string) {
    this.checkUrl = checkUrl;
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => this.handleOnline());
      window.addEventListener('offline', () => this.handleOffline());
    }
    if (this.online) this.checkServerReachability();
  }

  private handleOnline(): void {
    this.online = true;
    this.checkServerReachability();
  }

  private handleOffline(): void {
    this.online = false;
    this.serverReachable = false;
    this.notifyListeners();
  }

  async checkServerReachability(): Promise<boolean> {
    if (!this.online) {
      this.serverReachable = false;
      return false;
    }
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      const response = await fetch(this.checkUrl, { method: 'HEAD', signal: controller.signal, cache: 'no-store' });
      clearTimeout(timeout);
      this.serverReachable = response.ok;
    } catch {
      this.serverReachable = false;
    }
    this.notifyListeners();
    return this.serverReachable;
  }

  startPeriodicChecks(intervalMs: number = 30000): void {
    if (this.checkInterval) return;
    if (typeof window !== 'undefined') {
      this.checkInterval = window.setInterval(() => this.checkServerReachability(), intervalMs);
    }
  }

  stopPeriodicChecks(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
  }

  isOnline(): boolean { return this.online && this.serverReachable; }
  isNetworkAvailable(): boolean { return this.online; }

  subscribe(callback: ConnectivityCallback): () => void {
    this.listeners.add(callback);
    callback(this.isOnline());
    return () => this.listeners.delete(callback);
  }

  private notifyListeners(): void {
    const online = this.isOnline();
    this.listeners.forEach(cb => cb(online));
  }

  getConnectionQuality(): { type?: string; downlink?: number; rtt?: number } | null {
    if (typeof navigator !== 'undefined') {
      const connection = (navigator as any).connection;
      if (connection) return { type: connection.effectiveType, downlink: connection.downlink, rtt: connection.rtt };
    }
    return null;
  }
}

// ============================================================================
// SYNC ENGINE
// ============================================================================

export class SyncEngine {
  private db: OfflineDatabase;
  private config: SyncConfig;
  private connectivity: ConnectivityMonitor;
  private isSyncing: boolean = false;
  private syncTimer: number | null = null;
  private progressCallback: SyncProgressCallback | null = null;
  private criticalAlertFailedCallback: CriticalAlertFailedCallback | null = null;
  private unsubscribeConnectivity: (() => void) | null = null;
  private eventEmitter: ((event: string, data: any) => void) | null = null;

  constructor(db: OfflineDatabase, config: SyncConfig, connectivity: ConnectivityMonitor) {
    this.db = db;
    this.config = config;
    this.connectivity = connectivity;
    this.unsubscribeConnectivity = this.connectivity.subscribe((online) => {
      if (online) this.triggerSync();
    });
  }

  setEventEmitter(emitter: (event: string, data: any) => void): void { this.eventEmitter = emitter; }
  onProgress(callback: SyncProgressCallback): void { this.progressCallback = callback; }
  onCriticalAlertFailed(callback: CriticalAlertFailedCallback): void { this.criticalAlertFailedCallback = callback; }

  startAutoSync(): void {
    if (this.syncTimer) return;
    if (typeof window !== 'undefined') {
      this.syncTimer = window.setInterval(() => {
        if (this.connectivity.isOnline()) this.triggerSync();
      }, this.config.syncIntervalMs);
    }
    if (this.connectivity.isOnline()) this.triggerSync();
  }

  stopAutoSync(): void {
    if (this.syncTimer) { clearInterval(this.syncTimer); this.syncTimer = null; }
  }

  async triggerSync(): Promise<SyncResult> {
    if (this.isSyncing) return this.createEmptyResult('Sync already in progress');
    if (!this.connectivity.isOnline()) return this.createEmptyResult('No network connection');

    this.isSyncing = true;
    const startTime = Date.now();
    this.reportProgress({ phase: 'preparing', total: 0, completed: 0 });
    this.emitEvent(CLASSROOM_EXCURSION_EVENTS.SYNC_STARTED, {});

    let uploaded = 0, failed = 0, criticalFailed = 0, conflicts = 0;

    try {
      const pendingItems = await this.db.getPendingSyncItems();
      const total = pendingItems.length;
      if (total === 0) {
        this.reportProgress({ phase: 'complete', total: 0, completed: 0 });
        this.isSyncing = false;
        return this.createSuccessResult(0, 0, 0, 0, Date.now() - startTime);
      }

      const critical = pendingItems.filter(i => i.priority >= SyncPriority.CRITICAL);
      const high = pendingItems.filter(i => i.priority >= SyncPriority.HIGH && i.priority < SyncPriority.CRITICAL);
      const normal = pendingItems.filter(i => i.priority >= SyncPriority.NORMAL && i.priority < SyncPriority.HIGH);
      const low = pendingItems.filter(i => i.priority < SyncPriority.NORMAL);
      let completed = 0;

      // CRITICAL
      for (const item of critical) {
        this.reportProgress({ phase: 'uploading_critical', total, completed, currentPriority: SyncPriority.CRITICAL });
        const result = await this.syncCriticalItem(item);
        if (result.success) { uploaded++; await this.db.removeFromSyncQueue(item.id); }
        else { failed++; criticalFailed++; }
        completed++;
      }

      // HIGH
      for (const item of high) {
        this.reportProgress({ phase: 'uploading_high', total, completed, currentPriority: SyncPriority.HIGH });
        const result = await this.syncItem(item);
        if (result.success) { uploaded++; await this.db.removeFromSyncQueue(item.id); }
        else if (result.conflict) { conflicts++; await this.handleConflict(item, result.serverData); }
        else { failed++; await this.handleSyncFailure(item, result.error || 'Unknown'); }
        completed++;
      }

      // NORMAL
      for (const item of normal) {
        this.reportProgress({ phase: 'uploading_normal', total, completed, currentPriority: SyncPriority.NORMAL });
        const result = await this.syncItem(item);
        if (result.success) { uploaded++; await this.db.removeFromSyncQueue(item.id); }
        else if (result.conflict) { conflicts++; await this.handleConflict(item, result.serverData); }
        else { failed++; await this.handleSyncFailure(item, result.error || 'Unknown'); }
        completed++;
      }

      // LOW
      for (const item of low) {
        this.reportProgress({ phase: 'uploading_low', total, completed, currentPriority: SyncPriority.LOW });
        const result = await this.syncItem(item);
        if (result.success) { uploaded++; await this.db.removeFromSyncQueue(item.id); }
        else { failed++; await this.handleSyncFailure(item, result.error || 'Unknown'); }
        completed++;
      }

      // Resolve conflicts
      const unresolvedConflicts = await this.db.getUnresolvedConflicts();
      if (unresolvedConflicts.length > 0) {
        this.reportProgress({ phase: 'resolving_conflicts', total, completed });
        await this.resolveConflicts(unresolvedConflicts);
      }

      await this.db.setSyncMeta('lastSync', new Date().toISOString());
      this.reportProgress({ phase: 'complete', total, completed });
      const result = this.createSuccessResult(uploaded, failed, criticalFailed, conflicts, Date.now() - startTime);
      this.emitEvent(CLASSROOM_EXCURSION_EVENTS.SYNC_COMPLETED, result);
      return result;
    } catch (error) {
      this.reportProgress({ phase: 'error', total: 0, completed: 0 });
      return this.createEmptyResult((error as Error).message);
    } finally {
      this.isSyncing = false;
    }
  }

  private async syncCriticalItem(item: SyncQueueItem): Promise<{ success: boolean; error?: string }> {
    const maxRetries = 5;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        const result = await this.syncItem(item);
        if (result.success) return { success: true };
        if (attempt < maxRetries) await this.sleep(1000 * attempt);
      } catch (error) {
        if (attempt < maxRetries) await this.sleep(1000 * attempt);
      }
    }

    // SMS fallback
    if (this.config.enableSMSFallback && this.config.smsGatewayUrl) {
      const smsResult = await this.sendSMSFallback(item);
      if (smsResult.success) {
        await this.db.recordFailedCriticalAlert(item, 'API failed, SMS sent', true, 'sent');
        this.emitEvent(CLASSROOM_EXCURSION_EVENTS.CRITICAL_ALERT_FAILED, { item, error: 'API failed', smsFallback: 'sent' });
        return { success: true };
      }
      await this.db.recordFailedCriticalAlert(item, 'Both failed', true, 'failed');
      this.emitEvent(CLASSROOM_EXCURSION_EVENTS.CRITICAL_ALERT_FAILED, { item, error: 'Both failed', smsFallback: 'failed' });
      if (this.criticalAlertFailedCallback) this.criticalAlertFailedCallback(item, 'Both API and SMS failed');
    } else {
      await this.db.recordFailedCriticalAlert(item, 'API failed, no SMS', false);
      if (this.criticalAlertFailedCallback) this.criticalAlertFailedCallback(item, 'API failed, no SMS configured');
    }
    return { success: false, error: 'All delivery methods failed' };
  }

  private async sendSMSFallback(item: SyncQueueItem): Promise<{ success: boolean }> {
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (this.config.getSmsAuthToken) headers['Authorization'] = `Bearer ${await this.config.getSmsAuthToken()}`;
        
        const response = await fetch(this.config.smsGatewayUrl!, {
          method: 'POST',
          headers,
          body: JSON.stringify({
            type: 'excursion_emergency_alert',
            urgency: 'critical',
            recipients: this.config.emergencyContacts || [],
            message: this.formatAlertForSMS(item),
            timestamp: new Date().toISOString(),
            tenantId: this.config.tenantId
          })
        });
        if (response.ok) return { success: true };
      } catch { /* continue */ }
      if (attempt < 3) await this.sleep(1000 * attempt);
    }
    return { success: false };
  }

  private formatAlertForSMS(item: SyncQueueItem): string {
    const p = item.payload;
    if (item.type === 'alert' && item.entityType === 'missing_alert') {
      return `URGENT: MISSING STUDENT(S) - ${p.studentNames?.join(', ') || 'Unknown'} at ${p.checkpointName || 'Unknown'}. Reported by ${p.reportedBy || 'Staff'}. Respond immediately.`;
    }
    return `Scholarly Alert: ${item.type} - ${item.entityType}`;
  }

  private async syncItem(item: SyncQueueItem): Promise<{ success: boolean; conflict?: boolean; serverData?: any; error?: string }> {
    try {
      const token = await this.config.getAuthToken();
      const response = await fetch(`${this.config.apiBaseUrl}${this.getEndpointForItem(item)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`, 'X-Tenant-ID': this.config.tenantId },
        body: JSON.stringify(item.payload)
      });
      if (response.ok) return { success: true };
      if (response.status === 409) return { success: false, conflict: true, serverData: await response.json() };
      return { success: false, error: `${response.status}` };
    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }

  private getEndpointForItem(item: SyncQueueItem): string {
    const p = item.payload;
    switch (item.type) {
      case 'check_in': return `/excursions/${p.excursionId}/check-ins`;
      case 'capture': return `/excursions/${p.excursionId}/captures`;
      case 'alert': return `/excursions/${p.excursionId}/alerts`;
      default: return '/sync';
    }
  }

  private async handleSyncFailure(item: SyncQueueItem, error: string): Promise<void> {
    item.attempts++;
    item.lastAttempt = new Date();
    item.lastError = error;
    if (item.attempts < item.maxRetries) {
      await this.db.updateSyncItem(item.id, { attempts: item.attempts, lastAttempt: item.lastAttempt, lastError: item.lastError });
    } else {
      await this.db.removeFromSyncQueue(item.id);
    }
  }

  private async handleConflict(item: SyncQueueItem, serverData: any): Promise<void> {
    await this.db.recordConflict({ entityType: item.entityType, entityId: item.entityId, localVersion: item.payload, serverVersion: serverData, conflictFields: [] });
    this.emitEvent(CLASSROOM_EXCURSION_EVENTS.SYNC_CONFLICT, { entityType: item.entityType, entityId: item.entityId });
    await this.db.removeFromSyncQueue(item.id);
  }

  private async resolveConflicts(conflicts: ConflictRecord[]): Promise<void> {
    for (const conflict of conflicts) {
      const resolution = conflict.entityType === 'capture' ? 'local_wins' : 'server_wins';
      await this.db.resolveConflict(conflict.id, resolution, 'auto');
    }
  }

  private reportProgress(progress: SyncProgress): void { this.progressCallback?.(progress); }
  private emitEvent(event: string, data: any): void { this.eventEmitter?.(event, data); }
  private createEmptyResult(error: string): SyncResult { return { success: false, uploaded: 0, downloaded: 0, failed: 0, conflicts: 0, criticalPending: 0, criticalFailed: 0, duration: 0, errors: [error] }; }
  private createSuccessResult(uploaded: number, failed: number, criticalFailed: number, conflicts: number, duration: number): SyncResult { return { success: failed === 0 && criticalFailed === 0, uploaded, downloaded: 0, failed, conflicts, criticalPending: 0, criticalFailed, duration, errors: [] }; }
  private sleep(ms: number): Promise<void> { return new Promise(r => setTimeout(r, ms)); }

  async getSyncStatus(): Promise<{ isSyncing: boolean; isOnline: boolean; lastSync: string | null; pendingCount: number; criticalPending: number; failedCriticalAlerts: number }> {
    const [lastSync, pending, failedAlerts] = await Promise.all([this.db.getSyncMeta('lastSync'), this.db.getPendingSyncItems(), this.db.getUnresolvedFailedAlerts()]);
    return { isSyncing: this.isSyncing, isOnline: this.connectivity.isOnline(), lastSync, pendingCount: pending.length, criticalPending: pending.filter(i => i.priority >= SyncPriority.CRITICAL).length, failedCriticalAlerts: failedAlerts.length };
  }

  async forceSync(): Promise<SyncResult> { await this.connectivity.checkServerReachability(); return this.triggerSync(); }
  destroy(): void { this.stopAutoSync(); this.unsubscribeConnectivity?.(); }
}

// ============================================================================
// PREFLIGHT LOADER
// ============================================================================

export class PreflightLoader {
  private db: OfflineDatabase;
  private config: SyncConfig;

  constructor(db: OfflineDatabase, config: SyncConfig) { this.db = db; this.config = config; }

  async loadExcursionData(excursionId: string, onProgress?: (phase: string, progress: number) => void): Promise<{ success: boolean; error?: string }> {
    try {
      const token = await this.config.getAuthToken();
      const headers = { 'Authorization': `Bearer ${token}`, 'X-Tenant-ID': this.config.tenantId };

      onProgress?.('Loading excursion', 0);
      const excursionRes = await fetch(`${this.config.apiBaseUrl}/excursions/${excursionId}`, { headers });
      if (!excursionRes.ok) throw new Error('Failed to load excursion');
      const excursion = await excursionRes.json();
      await this.db.put(STORES.EXCURSIONS, { localId: generateLocalId(), excursionId: excursion.id, ...excursion, syncStatus: SyncStatus.SYNCED, cachedAt: new Date() });

      onProgress?.('Loading students', 25);
      const studentsRes = await fetch(`${this.config.apiBaseUrl}/excursions/${excursionId}/students`, { headers });
      if (studentsRes.ok) for (const s of await studentsRes.json()) await this.db.put(STORES.STUDENTS, { localId: generateLocalId(), excursionId, ...s, syncStatus: SyncStatus.SYNCED });

      onProgress?.('Loading checkpoints', 50);
      const cpRes = await fetch(`${this.config.apiBaseUrl}/excursions/${excursionId}/checkpoints`, { headers });
      if (cpRes.ok) for (const cp of await cpRes.json()) await this.db.put(STORES.CHECKPOINTS, { localId: generateLocalId(), excursionId, ...cp, syncStatus: SyncStatus.SYNCED });

      onProgress?.('Loading tasks', 75);
      const tasksRes = await fetch(`${this.config.apiBaseUrl}/excursions/${excursionId}/tasks`, { headers });
      if (tasksRes.ok) for (const t of await tasksRes.json()) await this.db.put(STORES.TASKS, { localId: generateLocalId(), excursionId, ...t, syncStatus: SyncStatus.SYNCED });

      await this.db.requestPersistentStorage();
      await this.db.setSyncMeta(`excursion_${excursionId}_cached`, new Date().toISOString());
      onProgress?.('Complete', 100);
      return { success: true };
    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }

  async isExcursionCached(excursionId: string): Promise<boolean> { return !!(await this.db.getSyncMeta(`excursion_${excursionId}_cached`)); }

  async clearExcursionCache(excursionId: string): Promise<void> {
    for (const store of [STORES.STUDENTS, STORES.CHECKPOINTS, STORES.TASKS, STORES.CHECK_INS]) {
      const items = await this.db.queryByIndex(store, 'by_excursion', excursionId);
      for (const item of items as any[]) await this.db.delete(store, item.localId);
    }
    const captures = await this.db.queryByIndex(STORES.CAPTURES, 'by_excursion', excursionId);
    for (const cap of captures as any[]) {
      if (cap.mediaBlobId) await this.db.deleteMedia(cap.mediaBlobId);
      await this.db.delete(STORES.CAPTURES, cap.localId);
    }
    await this.db.setSyncMeta(`excursion_${excursionId}_cached`, null);
  }
}
