/**
 * Excursion Service
 * 
 * Server-side service for managing school excursions, checkpoints,
 * check-ins, and safety alerts. Follows the ScholarlyBaseService
 * pattern established in the Intelligence Mesh.
 * 
 * @module IntelligenceMesh/ClassroomExcursion/Services
 * @version 2.0.0
 */

import {
  Result, success, failure, MeshBaseEntity,
  Excursion, ExcursionStudent, ExcursionCheckpoint, CheckInRecord,
  ExcursionStatus, CheckInStatus, ConsentStatus, GeoLocation,
  CLASSROOM_EXCURSION_EVENTS, AlertSeverity
} from '../types/classroom-excursion.types';

// ============================================================================
// REPOSITORY INTERFACES
// ============================================================================

export interface ExcursionRepository {
  findById(tenantId: string, id: string): Promise<Excursion | null>;
  findBySchool(tenantId: string, schoolId: string, filters?: ExcursionFilters): Promise<Excursion[]>;
  findByDateRange(tenantId: string, schoolId: string, start: Date, end: Date): Promise<Excursion[]>;
  create(excursion: Omit<Excursion, 'id' | 'createdAt' | 'updatedAt'>): Promise<Excursion>;
  update(tenantId: string, id: string, updates: Partial<Excursion>): Promise<Excursion | null>;
  delete(tenantId: string, id: string): Promise<boolean>;
}

export interface ExcursionStudentRepository {
  findByExcursion(tenantId: string, excursionId: string): Promise<ExcursionStudent[]>;
  findByStudent(tenantId: string, studentId: string): Promise<ExcursionStudent[]>;
  findById(tenantId: string, id: string): Promise<ExcursionStudent | null>;
  create(student: Omit<ExcursionStudent, 'id' | 'createdAt' | 'updatedAt'>): Promise<ExcursionStudent>;
  update(tenantId: string, id: string, updates: Partial<ExcursionStudent>): Promise<ExcursionStudent | null>;
  bulkCreate(students: Omit<ExcursionStudent, 'id' | 'createdAt' | 'updatedAt'>[]): Promise<ExcursionStudent[]>;
  updateStatus(tenantId: string, excursionId: string, studentId: string, status: CheckInStatus): Promise<void>;
}

export interface CheckpointRepository {
  findByExcursion(tenantId: string, excursionId: string): Promise<ExcursionCheckpoint[]>;
  findById(tenantId: string, id: string): Promise<ExcursionCheckpoint | null>;
  create(checkpoint: Omit<ExcursionCheckpoint, 'id' | 'createdAt' | 'updatedAt'>): Promise<ExcursionCheckpoint>;
  update(tenantId: string, id: string, updates: Partial<ExcursionCheckpoint>): Promise<ExcursionCheckpoint | null>;
  delete(tenantId: string, id: string): Promise<boolean>;
}

export interface CheckInRepository {
  findByExcursion(tenantId: string, excursionId: string): Promise<CheckInRecord[]>;
  findByCheckpoint(tenantId: string, excursionId: string, checkpointId: string): Promise<CheckInRecord[]>;
  findByStudent(tenantId: string, excursionId: string, studentId: string): Promise<CheckInRecord[]>;
  findById(tenantId: string, id: string): Promise<CheckInRecord | null>;
  create(checkIn: Omit<CheckInRecord, 'id' | 'createdAt' | 'updatedAt'>): Promise<CheckInRecord>;
  update(tenantId: string, id: string, updates: Partial<CheckInRecord>): Promise<CheckInRecord | null>;
  findMissingStudents(tenantId: string, excursionId: string): Promise<CheckInRecord[]>;
}

// ============================================================================
// TYPES
// ============================================================================

export interface ExcursionFilters {
  status?: ExcursionStatus[];
  dateFrom?: Date;
  dateTo?: Date;
  leadTeacherId?: string;
}

export interface CreateExcursionInput {
  tenantId: string;
  schoolId: string;
  name: string;
  description: string;
  purpose: string;
  date: Date;
  departureTime: Date;
  expectedReturnTime: Date;
  destination: Excursion['destination'];
  transport: Excursion['transport'];
  leadTeacher: Excursion['leadTeacher'];
  additionalStaff?: Excursion['additionalStaff'];
  emergencyContacts: Excursion['emergencyContacts'];
  cost?: Excursion['cost'];
  curriculumLinks?: string[];
  createdBy: string;
}

export interface CheckInInput {
  tenantId: string;
  excursionId: string;
  checkpointId: string;
  studentId: string;
  status: CheckInStatus;
  checkedBy: string;
  method: CheckInRecord['method'];
  location?: GeoLocation;
  notes?: string;
}

export interface BulkCheckInInput {
  tenantId: string;
  excursionId: string;
  checkpointId: string;
  checkIns: {
    studentId: string;
    status: CheckInStatus;
    notes?: string;
  }[];
  checkedBy: string;
  method: CheckInRecord['method'];
  location?: GeoLocation;
}

export interface MissingStudentAlertInput {
  tenantId: string;
  excursionId: string;
  checkpointId: string;
  studentIds: string[];
  reportedBy: string;
  location?: GeoLocation;
}

// ============================================================================
// EVENT BUS INTERFACE
// ============================================================================

export interface EventBus {
  publish(event: string, payload: any): Promise<void>;
}

// ============================================================================
// NOTIFICATION SERVICE INTERFACE
// ============================================================================

export interface NotificationService {
  sendSMS(phoneNumbers: string[], message: string): Promise<{ success: boolean; failures: string[] }>;
  sendPush(userIds: string[], title: string, body: string, data?: any): Promise<void>;
  sendEmail(emails: string[], subject: string, body: string): Promise<void>;
}

// ============================================================================
// EXCURSION SERVICE
// ============================================================================

export class ExcursionService {
  constructor(
    private excursionRepo: ExcursionRepository,
    private studentRepo: ExcursionStudentRepository,
    private checkpointRepo: CheckpointRepository,
    private checkInRepo: CheckInRepository,
    private eventBus: EventBus,
    private notificationService: NotificationService
  ) {}

  // ==========================================================================
  // EXCURSION MANAGEMENT
  // ==========================================================================

  async createExcursion(input: CreateExcursionInput): Promise<Result<Excursion>> {
    try {
      // Validate input
      if (!input.name || !input.date || !input.leadTeacher) {
        return failure({ code: 'VALIDATION_ERROR', message: 'Missing required fields' });
      }

      if (input.departureTime >= input.expectedReturnTime) {
        return failure({ code: 'VALIDATION_ERROR', message: 'Departure must be before return time' });
      }

      const excursion = await this.excursionRepo.create({
        ...input,
        status: ExcursionStatus.DRAFT,
        createdBy: input.createdBy,
        updatedBy: input.createdBy
      });

      await this.eventBus.publish(CLASSROOM_EXCURSION_EVENTS.EXCURSION_CREATED, {
        excursionId: excursion.id,
        tenantId: input.tenantId,
        schoolId: input.schoolId,
        name: excursion.name,
        date: excursion.date
      });

      return success(excursion);
    } catch (error) {
      return failure({ code: 'CREATE_FAILED', message: (error as Error).message });
    }
  }

  async getExcursion(tenantId: string, excursionId: string): Promise<Result<Excursion>> {
    const excursion = await this.excursionRepo.findById(tenantId, excursionId);
    if (!excursion) {
      return failure({ code: 'NOT_FOUND', message: 'Excursion not found' });
    }
    return success(excursion);
  }

  async listExcursions(tenantId: string, schoolId: string, filters?: ExcursionFilters): Promise<Result<Excursion[]>> {
    const excursions = await this.excursionRepo.findBySchool(tenantId, schoolId, filters);
    return success(excursions);
  }

  async approveExcursion(tenantId: string, excursionId: string, approvedBy: string): Promise<Result<Excursion>> {
    const excursion = await this.excursionRepo.findById(tenantId, excursionId);
    if (!excursion) {
      return failure({ code: 'NOT_FOUND', message: 'Excursion not found' });
    }

    if (excursion.status !== ExcursionStatus.PENDING_APPROVAL) {
      return failure({ code: 'INVALID_STATUS', message: 'Excursion is not pending approval' });
    }

    const updated = await this.excursionRepo.update(tenantId, excursionId, {
      status: ExcursionStatus.APPROVED,
      approvedBy,
      approvedAt: new Date(),
      updatedBy: approvedBy
    });

    if (!updated) {
      return failure({ code: 'UPDATE_FAILED', message: 'Failed to approve excursion' });
    }

    await this.eventBus.publish(CLASSROOM_EXCURSION_EVENTS.EXCURSION_APPROVED, {
      excursionId,
      tenantId,
      approvedBy,
      approvedAt: new Date()
    });

    return success(updated);
  }

  async startExcursion(tenantId: string, excursionId: string, startedBy: string): Promise<Result<Excursion>> {
    const excursion = await this.excursionRepo.findById(tenantId, excursionId);
    if (!excursion) {
      return failure({ code: 'NOT_FOUND', message: 'Excursion not found' });
    }

    if (excursion.status !== ExcursionStatus.READY && excursion.status !== ExcursionStatus.APPROVED) {
      return failure({ code: 'INVALID_STATUS', message: 'Excursion is not ready to start' });
    }

    const updated = await this.excursionRepo.update(tenantId, excursionId, {
      status: ExcursionStatus.IN_PROGRESS,
      updatedBy: startedBy
    });

    if (!updated) {
      return failure({ code: 'UPDATE_FAILED', message: 'Failed to start excursion' });
    }

    await this.eventBus.publish(CLASSROOM_EXCURSION_EVENTS.EXCURSION_STARTED, {
      excursionId,
      tenantId,
      startedBy,
      startedAt: new Date()
    });

    return success(updated);
  }

  async completeExcursion(tenantId: string, excursionId: string, completedBy: string): Promise<Result<Excursion>> {
    const excursion = await this.excursionRepo.findById(tenantId, excursionId);
    if (!excursion) {
      return failure({ code: 'NOT_FOUND', message: 'Excursion not found' });
    }

    // Check for missing students
    const missingCheckIns = await this.checkInRepo.findMissingStudents(tenantId, excursionId);
    if (missingCheckIns.length > 0) {
      return failure({ 
        code: 'MISSING_STUDENTS', 
        message: `Cannot complete: ${missingCheckIns.length} student(s) still marked as missing` 
      });
    }

    const updated = await this.excursionRepo.update(tenantId, excursionId, {
      status: ExcursionStatus.COMPLETED,
      actualReturnTime: new Date(),
      updatedBy: completedBy
    });

    if (!updated) {
      return failure({ code: 'UPDATE_FAILED', message: 'Failed to complete excursion' });
    }

    await this.eventBus.publish(CLASSROOM_EXCURSION_EVENTS.EXCURSION_COMPLETED, {
      excursionId,
      tenantId,
      completedBy,
      completedAt: new Date()
    });

    return success(updated);
  }

  // ==========================================================================
  // STUDENT MANAGEMENT
  // ==========================================================================

  async addStudentsToExcursion(
    tenantId: string,
    excursionId: string,
    studentInputs: Omit<ExcursionStudent, 'id' | 'createdAt' | 'updatedAt' | 'tenantId' | 'excursionId'>[],
    addedBy: string
  ): Promise<Result<ExcursionStudent[]>> {
    const excursion = await this.excursionRepo.findById(tenantId, excursionId);
    if (!excursion) {
      return failure({ code: 'NOT_FOUND', message: 'Excursion not found' });
    }

    const students = await this.studentRepo.bulkCreate(
      studentInputs.map(s => ({
        ...s,
        tenantId,
        excursionId,
        createdBy: addedBy,
        updatedBy: addedBy
      }))
    );

    return success(students);
  }

  async getExcursionStudents(tenantId: string, excursionId: string): Promise<Result<ExcursionStudent[]>> {
    const students = await this.studentRepo.findByExcursion(tenantId, excursionId);
    return success(students);
  }

  async updateStudentConsent(
    tenantId: string,
    excursionId: string,
    studentId: string,
    status: ConsentStatus,
    respondedBy: string
  ): Promise<Result<ExcursionStudent>> {
    const students = await this.studentRepo.findByExcursion(tenantId, excursionId);
    const student = students.find(s => s.studentId === studentId);
    
    if (!student) {
      return failure({ code: 'NOT_FOUND', message: 'Student not found on excursion' });
    }

    const updated = await this.studentRepo.update(tenantId, student.id, {
      consent: {
        ...student.consent,
        status,
        respondedAt: new Date(),
        respondedBy
      },
      updatedBy: respondedBy
    });

    if (!updated) {
      return failure({ code: 'UPDATE_FAILED', message: 'Failed to update consent' });
    }

    return success(updated);
  }

  // ==========================================================================
  // CHECKPOINT MANAGEMENT
  // ==========================================================================

  async createCheckpoint(
    tenantId: string,
    excursionId: string,
    checkpoint: Omit<ExcursionCheckpoint, 'id' | 'createdAt' | 'updatedAt' | 'tenantId' | 'excursionId'>,
    createdBy: string
  ): Promise<Result<ExcursionCheckpoint>> {
    const excursion = await this.excursionRepo.findById(tenantId, excursionId);
    if (!excursion) {
      return failure({ code: 'NOT_FOUND', message: 'Excursion not found' });
    }

    const created = await this.checkpointRepo.create({
      ...checkpoint,
      tenantId,
      excursionId,
      createdBy,
      updatedBy: createdBy
    });

    return success(created);
  }

  async getCheckpoints(tenantId: string, excursionId: string): Promise<Result<ExcursionCheckpoint[]>> {
    const checkpoints = await this.checkpointRepo.findByExcursion(tenantId, excursionId);
    return success(checkpoints.sort((a, b) => a.order - b.order));
  }

  async completeCheckpoint(
    tenantId: string,
    excursionId: string,
    checkpointId: string,
    completedBy: string,
    notes?: string
  ): Promise<Result<ExcursionCheckpoint>> {
    const checkpoint = await this.checkpointRepo.findById(tenantId, checkpointId);
    if (!checkpoint || checkpoint.excursionId !== excursionId) {
      return failure({ code: 'NOT_FOUND', message: 'Checkpoint not found' });
    }

    const updated = await this.checkpointRepo.update(tenantId, checkpointId, {
      isComplete: true,
      completedBy,
      completedAt: new Date(),
      actualTime: new Date(),
      notes,
      updatedBy: completedBy
    });

    if (!updated) {
      return failure({ code: 'UPDATE_FAILED', message: 'Failed to complete checkpoint' });
    }

    await this.eventBus.publish(CLASSROOM_EXCURSION_EVENTS.CHECKPOINT_COMPLETED, {
      excursionId,
      checkpointId,
      tenantId,
      completedBy,
      completedAt: new Date()
    });

    return success(updated);
  }

  // ==========================================================================
  // CHECK-IN OPERATIONS (SAFETY CRITICAL)
  // ==========================================================================

  async checkInStudent(input: CheckInInput): Promise<Result<CheckInRecord>> {
    const { tenantId, excursionId, checkpointId, studentId, status, checkedBy, method, location, notes } = input;

    // Validate excursion exists and is in progress
    const excursion = await this.excursionRepo.findById(tenantId, excursionId);
    if (!excursion) {
      return failure({ code: 'NOT_FOUND', message: 'Excursion not found' });
    }

    // Create check-in record
    const checkIn = await this.checkInRepo.create({
      tenantId,
      excursionId,
      checkpointId,
      studentId,
      status,
      checkedAt: new Date(),
      checkedBy,
      method,
      location,
      notes,
      syncStatus: 'synced' as any,
      createdBy: checkedBy,
      updatedBy: checkedBy
    });

    // Update student status
    await this.studentRepo.updateStatus(tenantId, excursionId, studentId, status);

    // If missing, trigger alert
    if (status === CheckInStatus.MISSING) {
      await this.handleMissingStudent(tenantId, excursion, checkIn);
    }

    await this.eventBus.publish(CLASSROOM_EXCURSION_EVENTS.ATTENDANCE_UPDATED, {
      excursionId,
      checkpointId,
      studentId,
      status,
      checkedBy,
      checkedAt: checkIn.checkedAt
    });

    return success(checkIn);
  }

  async bulkCheckIn(input: BulkCheckInInput): Promise<Result<{ checkIns: CheckInRecord[]; missingCount: number }>> {
    const { tenantId, excursionId, checkpointId, checkIns, checkedBy, method, location } = input;

    const excursion = await this.excursionRepo.findById(tenantId, excursionId);
    if (!excursion) {
      return failure({ code: 'NOT_FOUND', message: 'Excursion not found' });
    }

    const results: CheckInRecord[] = [];
    const missingStudentIds: string[] = [];

    for (const ci of checkIns) {
      const result = await this.checkInStudent({
        tenantId,
        excursionId,
        checkpointId,
        studentId: ci.studentId,
        status: ci.status,
        checkedBy,
        method,
        location,
        notes: ci.notes
      });

      if (result.success) {
        results.push(result.data);
        if (ci.status === CheckInStatus.MISSING) {
          missingStudentIds.push(ci.studentId);
        }
      }
    }

    // Send bulk missing alert if any
    if (missingStudentIds.length > 0) {
      await this.sendMissingStudentAlert({
        tenantId,
        excursionId,
        checkpointId,
        studentIds: missingStudentIds,
        reportedBy: checkedBy,
        location
      });
    }

    return success({ checkIns: results, missingCount: missingStudentIds.length });
  }

  async markStudentFound(
    tenantId: string,
    excursionId: string,
    studentId: string,
    foundBy: string,
    location?: GeoLocation,
    notes?: string
  ): Promise<Result<CheckInRecord>> {
    // Find the missing check-in
    const checkIns = await this.checkInRepo.findByStudent(tenantId, excursionId, studentId);
    const missingCheckIn = checkIns.find(ci => ci.status === CheckInStatus.MISSING && !ci.foundAt);

    if (!missingCheckIn) {
      return failure({ code: 'NOT_FOUND', message: 'No missing record found for student' });
    }

    // Update the missing record
    const updated = await this.checkInRepo.update(tenantId, missingCheckIn.id, {
      foundAt: new Date(),
      foundBy,
      foundLocation: location,
      foundNotes: notes,
      updatedBy: foundBy
    });

    if (!updated) {
      return failure({ code: 'UPDATE_FAILED', message: 'Failed to update record' });
    }

    // Update student status
    await this.studentRepo.updateStatus(tenantId, excursionId, studentId, CheckInStatus.AT_DESTINATION);

    // Get student info for event
    const students = await this.studentRepo.findByExcursion(tenantId, excursionId);
    const student = students.find(s => s.studentId === studentId);

    await this.eventBus.publish(CLASSROOM_EXCURSION_EVENTS.STUDENT_FOUND, {
      excursionId,
      studentId,
      studentName: student?.studentName,
      foundBy,
      foundAt: new Date(),
      location
    });

    // Send notification
    const excursion = await this.excursionRepo.findById(tenantId, excursionId);
    if (excursion) {
      const phones = [excursion.leadTeacher.mobile, ...excursion.additionalStaff.map(s => s.mobile)];
      await this.notificationService.sendSMS(
        phones,
        `GOOD NEWS: ${student?.studentName || 'Student'} has been found and is safe. Reported by ${foundBy}.`
      );
    }

    return success(updated);
  }

  // ==========================================================================
  // ALERT HANDLING
  // ==========================================================================

  private async handleMissingStudent(
    tenantId: string,
    excursion: Excursion,
    checkIn: CheckInRecord
  ): Promise<void> {
    const students = await this.studentRepo.findByExcursion(tenantId, excursion.id);
    const student = students.find(s => s.studentId === checkIn.studentId);

    await this.sendMissingStudentAlert({
      tenantId,
      excursionId: excursion.id,
      checkpointId: checkIn.checkpointId,
      studentIds: [checkIn.studentId],
      reportedBy: checkIn.checkedBy,
      location: checkIn.location
    });
  }

  async sendMissingStudentAlert(input: MissingStudentAlertInput): Promise<void> {
    const { tenantId, excursionId, checkpointId, studentIds, reportedBy, location } = input;

    const excursion = await this.excursionRepo.findById(tenantId, excursionId);
    if (!excursion) return;

    const students = await this.studentRepo.findByExcursion(tenantId, excursionId);
    const missingStudents = students.filter(s => studentIds.includes(s.studentId));
    const checkpoint = await this.checkpointRepo.findById(tenantId, checkpointId);

    const studentNames = missingStudents.map(s => s.studentName);

    // Publish event
    await this.eventBus.publish(CLASSROOM_EXCURSION_EVENTS.STUDENTS_MISSING, {
      excursionId,
      checkpointId,
      checkpointName: checkpoint?.name,
      studentIds,
      studentNames,
      reportedBy,
      reportedAt: new Date(),
      location,
      severity: AlertSeverity.EMERGENCY
    });

    // Send SMS to all staff
    const phones = [
      excursion.leadTeacher.mobile,
      ...excursion.additionalStaff.map(s => s.mobile),
      ...excursion.emergencyContacts.map(c => c.phone)
    ].filter(Boolean);

    const message = `URGENT: MISSING STUDENT(S) on ${excursion.name}\n` +
      `Students: ${studentNames.join(', ')}\n` +
      `Location: ${checkpoint?.name || 'Unknown'}\n` +
      `Reported by: ${reportedBy}\n` +
      `Time: ${new Date().toLocaleTimeString()}\n` +
      `RESPOND IMMEDIATELY`;

    await this.notificationService.sendSMS(phones, message);

    // Send push notifications
    const staffIds = [excursion.leadTeacher.id, ...excursion.additionalStaff.map(s => s.id)];
    await this.notificationService.sendPush(
      staffIds,
      '🚨 MISSING STUDENT ALERT',
      `${studentNames.join(', ')} missing at ${checkpoint?.name}`,
      { excursionId, checkpointId, studentIds, type: 'missing_student' }
    );
  }

  // ==========================================================================
  // HEAD COUNT
  // ==========================================================================

  async performHeadCount(
    tenantId: string,
    excursionId: string,
    actualCount: number,
    location: GeoLocation,
    performedBy: string
  ): Promise<Result<{ expected: number; actual: number; discrepancy: number; alert: boolean }>> {
    const students = await this.studentRepo.findByExcursion(tenantId, excursionId);
    const expected = students.filter(s => 
      s.currentStatus !== CheckInStatus.EARLY_DEPARTURE
    ).length;

    const discrepancy = expected - actualCount;
    const alert = discrepancy !== 0;

    if (alert) {
      await this.eventBus.publish(CLASSROOM_EXCURSION_EVENTS.HEAD_COUNT_DISCREPANCY, {
        excursionId,
        tenantId,
        expected,
        actual: actualCount,
        discrepancy,
        location,
        performedBy,
        performedAt: new Date()
      });

      // If significant discrepancy, notify staff
      if (Math.abs(discrepancy) > 0) {
        const excursion = await this.excursionRepo.findById(tenantId, excursionId);
        if (excursion) {
          const phones = [excursion.leadTeacher.mobile];
          await this.notificationService.sendSMS(
            phones,
            `HEAD COUNT ALERT: Expected ${expected}, counted ${actualCount}. Discrepancy: ${discrepancy}. Please verify.`
          );
        }
      }
    }

    return success({ expected, actual: actualCount, discrepancy, alert });
  }

  // ==========================================================================
  // DASHBOARD DATA
  // ==========================================================================

  async getExcursionDashboard(tenantId: string, excursionId: string): Promise<Result<any>> {
    const excursion = await this.excursionRepo.findById(tenantId, excursionId);
    if (!excursion) {
      return failure({ code: 'NOT_FOUND', message: 'Excursion not found' });
    }

    const students = await this.studentRepo.findByExcursion(tenantId, excursionId);
    const checkpoints = await this.checkpointRepo.findByExcursion(tenantId, excursionId);
    const allCheckIns = await this.checkInRepo.findByExcursion(tenantId, excursionId);

    // Calculate head count
    const total = students.length;
    const checkedIn = students.filter(s => 
      s.currentStatus === CheckInStatus.AT_DESTINATION || 
      s.currentStatus === CheckInStatus.DEPARTED
    ).length;
    const missing = students.filter(s => s.currentStatus === CheckInStatus.MISSING).length;
    const medical = students.filter(s => s.currentStatus === CheckInStatus.MEDICAL).length;
    const earlyDeparture = students.filter(s => s.currentStatus === CheckInStatus.EARLY_DEPARTURE).length;

    // Find current and next checkpoint
    const sortedCheckpoints = checkpoints.sort((a, b) => a.order - b.order);
    const currentCheckpoint = sortedCheckpoints.find(cp => !cp.isComplete);
    const nextCheckpoint = currentCheckpoint 
      ? sortedCheckpoints.find(cp => cp.order > currentCheckpoint.order)
      : null;

    return success({
      excursionId,
      refreshedAt: new Date(),
      overview: {
        status: excursion.status,
        currentCheckpoint: currentCheckpoint?.name,
        nextCheckpoint: nextCheckpoint?.name
      },
      headCount: {
        total,
        checkedIn,
        missing,
        medical,
        earlyDeparture
      },
      checkpoints: sortedCheckpoints.map(cp => ({
        id: cp.id,
        name: cp.name,
        isComplete: cp.isComplete,
        scheduledTime: cp.scheduledTime,
        actualTime: cp.actualTime
      })),
      alerts: missing > 0 ? [{
        type: 'missing',
        message: `${missing} student(s) marked as missing`,
        severity: AlertSeverity.EMERGENCY
      }] : []
    });
  }
}
