/**
 * Classroom & Excursion Module - Type Definitions
 * 
 * Extends the Intelligence Mesh Attendance module with:
 * - AI-Assisted Roll Call with seating arrangements
 * - Real-time help requests during lessons
 * - Offline-capable excursion management
 * - Outdoor discovery and capture tools
 * - End-of-lesson feedback with school pulse
 * 
 * ## The Granny Explanation
 * 
 * Imagine a school excursion to the national park. It's beautiful but there's
 * no phone signal. The teacher needs to count heads at every checkpoint -
 * missing a child could be catastrophic. With paper lists, they tick names,
 * but what if the list blows away? What if they miscount?
 * 
 * This module is like having a smart clipboard that:
 * - Works without internet (stores everything locally)
 * - Instantly alerts if someone's missing at a checkpoint
 * - Sends the alert the moment signal returns
 * - Lets kids capture photos/notes for their assignment
 * - Tracks who's done what, even offline
 * 
 * Back in the classroom, it's like having eyes in the back of your head:
 * - Kids can silently flag "I'm stuck" without embarrassment
 * - Seating is optimized so troublemakers don't sit together
 * - End-of-lesson feedback tells the principal which lessons are struggling
 * 
 * @module IntelligenceMesh/ClassroomExcursion
 * @version 2.0.0
 */

// ============================================================================
// BASE TYPES (Duplicated from mesh-types for standalone capability)
// When integrating, these can be imported from @scholarly/intelligence-mesh
// ============================================================================

/**
 * Base entity interface - all mesh entities extend this
 */
export interface MeshBaseEntity {
  id: string;
  tenantId: string;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  updatedBy: string;
  deletedAt?: Date;
  deletedBy?: string;
}

/**
 * Attendance status from core attendance module
 */
export type AttendanceStatus = 
  | 'present'
  | 'absent'
  | 'late'
  | 'excused'
  | 'partial'
  | 'remote';

/**
 * Result type for service operations
 */
export type Result<T> = 
  | { success: true; data: T }
  | { success: false; error: { code: string; message: string } };

export function success<T>(data: T): Result<T> {
  return { success: true, data };
}

export function failure(error: { code: string; message: string }): Result<never> {
  return { success: false, error };
}

// ============================================================================
// ENUMS
// ============================================================================

/**
 * Methods for taking roll call
 */
export enum RollCallMethod {
  MANUAL = 'manual',
  QR_SCAN = 'qr_scan',
  NFC_TAP = 'nfc_tap',
  FACIAL = 'facial',
  VOICE = 'voice',
  GEOFENCE = 'geofence',
  AI_ASSISTED = 'ai_assisted'
}

/**
 * Seating arrangement layouts
 */
export enum SeatingLayoutType {
  ROWS = 'rows',
  CLUSTERS = 'clusters',
  U_SHAPE = 'u_shape',
  CIRCLE = 'circle',
  PAIRS = 'pairs',
  FLEXIBLE = 'flexible',
  CUSTOM = 'custom'
}

/**
 * AI strategies for seating optimization
 */
export enum SeatingStrategy {
  MANUAL = 'manual',
  RANDOM = 'random',
  ALPHABETICAL = 'alphabetical',
  AI_COLLABORATIVE = 'ai_collaborative',
  AI_MINIMIZE_DISRUPTION = 'ai_minimize_disruption',
  AI_PEER_SUPPORT = 'ai_peer_support',
  MIXED_ABILITY = 'mixed_ability',
  ABILITY_GROUPED = 'ability_grouped'
}

/**
 * Types of help a student can request
 */
export enum HelpRequestType {
  CLARIFICATION = 'clarification',
  STUCK = 'stuck',
  PREREQUISITE_GAP = 'prerequisite_gap',
  PACE_TOO_FAST = 'pace_too_fast',
  PACE_TOO_SLOW = 'pace_too_slow',
  TECHNICAL = 'technical',
  WELLBEING = 'wellbeing',
  OTHER = 'other'
}

/**
 * Urgency levels for help requests
 */
export enum HelpUrgency {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical'
}

/**
 * Help request status progression
 */
export enum HelpRequestStatus {
  PENDING = 'pending',
  ACKNOWLEDGED = 'acknowledged',
  IN_PROGRESS = 'in_progress',
  RESOLVED = 'resolved',
  CANCELLED = 'cancelled',
  DEFERRED = 'deferred'
}

/**
 * Excursion lifecycle states
 */
export enum ExcursionStatus {
  DRAFT = 'draft',
  PENDING_APPROVAL = 'pending_approval',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  PERMISSIONS_SENT = 'permissions_sent',
  READY = 'ready',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  CANCELLED = 'cancelled'
}

/**
 * Parent consent status for excursions
 */
export enum ConsentStatus {
  NOT_REQUESTED = 'not_requested',
  REQUESTED = 'requested',
  REMINDED = 'reminded',
  GRANTED = 'granted',
  DENIED = 'denied',
  EXPIRED = 'expired'
}

/**
 * Student check-in status during excursion
 */
export enum CheckInStatus {
  NOT_CHECKED_IN = 'not_checked_in',
  DEPARTED = 'departed',
  AT_DESTINATION = 'at_destination',
  RETURNING = 'returning',
  RETURNED = 'returned',
  MISSING = 'missing',
  MEDICAL = 'medical',
  EARLY_DEPARTURE = 'early_departure'
}

/**
 * Types of captures for outdoor discovery
 */
export enum CaptureType {
  PHOTO = 'photo',
  VIDEO = 'video',
  AUDIO = 'audio',
  TEXT_NOTE = 'text_note',
  VOICE_MEMO = 'voice_memo',
  SKETCH = 'sketch',
  LOCATION_PIN = 'location_pin',
  SENSOR_DATA = 'sensor_data',
  QR_SCAN = 'qr_scan',
  AR_MARKER = 'ar_marker'
}

/**
 * Discovery task completion status
 */
export enum TaskStatus {
  NOT_STARTED = 'not_started',
  IN_PROGRESS = 'in_progress',
  SUBMITTED = 'submitted',
  REVIEWED = 'reviewed',
  COMPLETED = 'completed',
  SKIPPED = 'skipped'
}

/**
 * Feedback question types
 */
export enum FeedbackQuestionType {
  RATING = 'rating',
  EMOJI = 'emoji',
  SLIDER = 'slider',
  MULTIPLE_CHOICE = 'multiple_choice',
  BOOLEAN = 'boolean',
  FREE_TEXT = 'free_text'
}

/**
 * Sentiment analysis results
 */
export enum Sentiment {
  VERY_NEGATIVE = 'very_negative',
  NEGATIVE = 'negative',
  NEUTRAL = 'neutral',
  POSITIVE = 'positive',
  VERY_POSITIVE = 'very_positive'
}

/**
 * Sync status for offline records
 */
export enum SyncStatus {
  PENDING = 'pending',
  SYNCING = 'syncing',
  SYNCED = 'synced',
  FAILED = 'failed',
  CONFLICT = 'conflict'
}

/**
 * Sync priority (higher = sync first)
 */
export enum SyncPriority {
  CRITICAL = 100,  // Missing student alerts
  HIGH = 75,       // Check-ins, attendance
  NORMAL = 50,     // Captures, progress
  LOW = 25         // Analytics
}

/**
 * Alert severity levels
 */
export enum AlertSeverity {
  INFO = 'info',
  WARNING = 'warning',
  CRITICAL = 'critical',
  EMERGENCY = 'emergency'
}

// ============================================================================
// GEOGRAPHIC TYPES
// ============================================================================

/**
 * Geographic location
 */
export interface GeoLocation {
  latitude: number;
  longitude: number;
  accuracy?: number;
  altitude?: number;
  timestamp?: Date;
}

/**
 * Geofence definition
 */
export interface Geofence {
  id: string;
  name: string;
  center: GeoLocation;
  radiusMeters: number;
  type: 'circle' | 'polygon';
  polygonPoints?: GeoLocation[];
}

// ============================================================================
// CLASS SESSION INTERFACES
// ============================================================================

/**
 * A class session (specific instance of a scheduled class)
 */
export interface ClassSession extends MeshBaseEntity {
  schoolId: string;
  classId: string;
  className: string;
  subject: string;
  yearLevel: string;
  
  teacherId: string;
  teacherName: string;
  
  roomId?: string;
  roomName?: string;
  
  scheduledStart: Date;
  scheduledEnd: Date;
  actualStart?: Date;
  actualEnd?: Date;
  
  periodNumber?: number;
  timetableSlotId?: string;
  lessonPlanId?: string;
  curriculumCodes?: string[];
  
  expectedStudentIds: string[];
  
  seatingArrangementId?: string;
  excursionId?: string;
  
  status: 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
}

/**
 * Roll call for a class session
 */
export interface SessionRollCall extends MeshBaseEntity {
  sessionId: string;
  
  takenAt: Date;
  takenBy: string;
  method: RollCallMethod;
  
  isReRoll: boolean;
  previousRollCallId?: string;
  
  attendance: StudentSessionAttendance[];
  
  summary: {
    total: number;
    present: number;
    absent: number;
    late: number;
    excused: number;
  };
  
  aiSuggestions?: AIRollCallSuggestion[];
  
  location?: GeoLocation;
  deviceId?: string;
  
  syncStatus: SyncStatus;
  syncedAt?: Date;
}

/**
 * Individual student attendance in a session
 */
export interface StudentSessionAttendance {
  studentId: string;
  studentName: string;
  
  status: AttendanceStatus;
  markedAt: Date;
  markedBy: string;
  
  arrivalTime?: Date;
  departureTime?: Date;
  
  reason?: string;
  reasonApproved?: boolean;
  parentNotified?: boolean;
  
  notes?: string;
  
  aiConfidence?: number;
  wasOverridden?: boolean;
  seatId?: string;
}

/**
 * AI suggestion for roll call
 */
export interface AIRollCallSuggestion {
  studentId: string;
  suggestedStatus: AttendanceStatus;
  confidence: number;
  reasoning: string;
  basedOn: ('historical_pattern' | 'visual_recognition' | 'device_proximity' | 'schedule_analysis')[];
}

// ============================================================================
// SEATING INTERFACES
// ============================================================================

/**
 * Classroom layout definition
 */
export interface ClassroomLayout extends MeshBaseEntity {
  roomId: string;
  roomName: string;
  
  type: SeatingLayoutType;
  
  dimensions: {
    width: number;
    height: number;
    unit: 'meters' | 'feet';
  };
  
  seats: SeatDefinition[];
  
  features: {
    teacherDesk?: { x: number; y: number };
    whiteboard?: { x: number; y: number; width: number };
    projector?: { x: number; y: number };
    doors?: { x: number; y: number; label: string }[];
    windows?: { x: number; y: number; width: number }[];
  };
  
  zones?: {
    id: string;
    name: string;
    seats: string[];
    color?: string;
  }[];
}

/**
 * Individual seat definition
 */
export interface SeatDefinition {
  id: string;
  position: { x: number; y: number };
  row?: number;
  column?: number;
  clusterId?: string;
  
  accessibility: {
    wheelchair: boolean;
    hearingLoop: boolean;
    nearDoor: boolean;
    nearWindow: boolean;
  };
  
  equipment?: string[];
  isAvailable: boolean;
}

/**
 * Seating arrangement for a session
 */
export interface SeatingArrangement extends MeshBaseEntity {
  layoutId: string;
  sessionId?: string;
  classId: string;
  
  name: string;
  strategy: SeatingStrategy;
  
  assignments: SeatAssignment[];
  
  generatedBy: 'manual' | 'ai';
  aiParameters?: {
    optimizeFor: string[];
    constraints: string[];
    modelVersion: string;
  };
  
  effectiveness?: {
    disruptionScore?: number;
    collaborationScore?: number;
    feedbackScore?: number;
    lastEvaluated: Date;
  };
}

/**
 * Student seat assignment
 */
export interface SeatAssignment {
  seatId: string;
  studentId: string;
  studentName: string;
  
  assignedAt: Date;
  assignedBy: string;
  
  reason?: string;
  
  preferences?: {
    nearFront: boolean;
    nearDoor: boolean;
    awayFromWindow: boolean;
    specificNeeds?: string[];
  };
}

// ============================================================================
// HELP REQUEST INTERFACES
// ============================================================================

/**
 * Real-time help request from a student
 */
export interface HelpRequest extends MeshBaseEntity {
  sessionId: string;
  studentId: string;
  studentName: string;
  seatId?: string;
  
  type: HelpRequestType;
  urgency: HelpUrgency;
  status: HelpRequestStatus;
  
  description?: string;
  context?: {
    currentActivity?: string;
    lastInteraction?: string;
    timeOnTask?: number;
  };
  
  requestedAt: Date;
  acknowledgedAt?: Date;
  resolvedAt?: Date;
  
  resolvedBy?: string;
  resolution?: string;
  followUpRequired?: boolean;
  
  aiAnalysis?: {
    suggestedApproach: string;
    relatedConcepts: string[];
    prerequisiteGaps?: string[];
    similarPastRequests?: number;
  };
}

/**
 * Post-lesson help request submitted after class
 */
export interface PostLessonHelpRequest extends MeshBaseEntity {
  sessionId: string;
  studentId: string;
  anonymousId: string;
  
  confusedTopics: string[];
  specificQuestions: string[];
  
  preferredHelpMethod: 'one_on_one' | 'small_group' | 'online_resource' | 'peer_tutoring';
  availableTimes?: string[];
  
  submittedAt: Date;
  reviewedAt?: Date;
  actionTaken?: string;
}

// ============================================================================
// EXCURSION INTERFACES
// ============================================================================

/**
 * School excursion definition
 */
export interface Excursion extends MeshBaseEntity {
  schoolId: string;
  
  name: string;
  description: string;
  purpose: string;
  curriculumLinks?: string[];
  
  date: Date;
  departureTime: Date;
  expectedReturnTime: Date;
  actualReturnTime?: Date;
  
  status: ExcursionStatus;
  
  destination: {
    name: string;
    address: string;
    location: GeoLocation;
    contactName?: string;
    contactPhone?: string;
  };
  
  transport: {
    method: 'bus' | 'walking' | 'train' | 'ferry' | 'mixed';
    provider?: string;
    vehicleDetails?: string;
    meetingPoint?: string;
  };
  
  cost?: {
    perStudent: number;
    currency: string;
    paymentDeadline?: Date;
  };
  
  leadTeacher: {
    id: string;
    name: string;
    mobile: string;
  };
  
  additionalStaff: {
    id: string;
    name: string;
    mobile: string;
    role: string;
  }[];
  
  emergencyContacts: {
    name: string;
    phone: string;
    role: string;
  }[];
  
  riskAssessmentId?: string;
  approvedBy?: string;
  approvedAt?: Date;
}

/**
 * Student participation in an excursion
 */
export interface ExcursionStudent extends MeshBaseEntity {
  excursionId: string;
  studentId: string;
  studentName: string;
  yearLevel: string;
  classId: string;
  
  groupId?: string;
  groupName?: string;
  
  consent: {
    status: ConsentStatus;
    requestedAt?: Date;
    respondedAt?: Date;
    respondedBy?: string;
    consentFormId?: string;
  };
  
  payment?: {
    required: number;
    paid: number;
    method?: string;
    paidAt?: Date;
  };
  
  medicalInfo: {
    conditions: string[];
    medications: string[];
    allergies: string[];
    dietaryRequirements: string[];
    actionPlanId?: string;
  };
  
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
    alternatePhone?: string;
  };
  
  currentStatus: CheckInStatus;
  lastCheckIn?: {
    checkpointId: string;
    checkpointName: string;
    time: Date;
    location?: GeoLocation;
  };
}

/**
 * Checkpoint for excursion tracking
 */
export interface ExcursionCheckpoint extends MeshBaseEntity {
  excursionId: string;
  
  name: string;
  description?: string;
  type: 'departure' | 'arrival' | 'activity' | 'meal' | 'return' | 'custom';
  
  scheduledTime: Date;
  actualTime?: Date;
  
  location?: GeoLocation;
  geofence?: Geofence;
  
  requiresHeadCount: boolean;
  requiresPhotoEvidence?: boolean;
  
  order: number;
  isComplete: boolean;
  completedBy?: string;
  completedAt?: Date;
  
  notes?: string;
}

/**
 * Check-in record for a student at a checkpoint
 */
export interface CheckInRecord extends MeshBaseEntity {
  excursionId: string;
  checkpointId: string;
  studentId: string;
  
  status: CheckInStatus;
  checkedAt: Date;
  checkedBy: string;
  
  method: 'manual' | 'qr_scan' | 'geofence' | 'nfc' | 'facial';
  location?: GeoLocation;
  
  notes?: string;
  photoEvidenceId?: string;
  
  // For missing → found tracking
  reportedMissingAt?: Date;
  foundAt?: Date;
  foundBy?: string;
  foundLocation?: GeoLocation;
  foundNotes?: string;
  
  syncStatus: SyncStatus;
  syncedAt?: Date;
}

// ============================================================================
// DISCOVERY TASK INTERFACES
// ============================================================================

/**
 * Discovery task for outdoor learning
 */
export interface DiscoveryTask extends MeshBaseEntity {
  excursionId: string;
  
  title: string;
  instructions: string;
  learningObjectives?: string[];
  curriculumCodes?: string[];
  
  type: 'individual' | 'group' | 'class';
  
  requiredCaptures: {
    type: CaptureType;
    count: number;
    description?: string;
  }[];
  
  optionalCaptures?: {
    type: CaptureType;
    maxCount: number;
    bonusPoints?: number;
  }[];
  
  locationBound?: {
    geofence: Geofence;
    locationName: string;
  };
  
  timeBound?: {
    availableFrom: Date;
    availableUntil: Date;
  };
  
  points?: number;
  difficulty?: 'easy' | 'medium' | 'hard' | 'challenge';
  
  hints?: string[];
  teacherNotes?: string;
  
  rubric?: {
    criteria: string;
    levels: { score: number; description: string }[];
  }[];
  
  order: number;
  isRequired: boolean;
}

/**
 * Student/group progress on a task
 */
export interface DiscoveryTaskProgress extends MeshBaseEntity {
  excursionId: string;
  taskId: string;
  
  participantType: 'student' | 'group';
  participantId: string;
  participantName: string;
  
  status: TaskStatus;
  
  startedAt?: Date;
  submittedAt?: Date;
  reviewedAt?: Date;
  
  captureIds: string[];
  captureCount: number;
  
  score?: number;
  feedback?: string;
  reviewedBy?: string;
  
  location?: GeoLocation;
  timeSpent?: number;
}

/**
 * Student capture (photo, note, etc.)
 */
export interface StudentCapture extends MeshBaseEntity {
  excursionId: string;
  taskId: string;
  
  participantType: 'student' | 'group';
  participantId: string;
  
  type: CaptureType;
  
  // Media captures
  mediaUrl?: string;
  thumbnailUrl?: string;
  mediaMimeType?: string;
  mediaSize?: number;
  mediaDuration?: number;
  
  // Text captures
  textContent?: string;
  
  // Metadata
  caption?: string;
  tags?: string[];
  location?: GeoLocation;
  
  // Transcription for audio/video
  transcription?: string;
  transcriptionConfidence?: number;
  
  // Sensor data
  sensorData?: {
    sensorType: string;
    value: number;
    unit: string;
    calibrated: boolean;
  };
  
  // QR/AR data
  scannedCode?: string;
  arMarkerId?: string;
  
  capturedAt: Date;
  
  aiAnalysis?: {
    objects?: string[];
    text?: string;
    sentiment?: Sentiment;
    quality?: number;
    suggestions?: string[];
  };
  
  teacherFeedback?: string;
  score?: number;
  
  syncStatus: SyncStatus;
  syncedAt?: Date;
}

// ============================================================================
// EXCURSION DASHBOARD INTERFACES
// ============================================================================

/**
 * Real-time excursion dashboard data
 */
export interface ExcursionDashboard {
  excursionId: string;
  refreshedAt: Date;
  
  overview: {
    status: ExcursionStatus;
    currentCheckpoint?: string;
    nextCheckpoint?: string;
    timeUntilNextCheckpoint?: number;
  };
  
  headCount: {
    total: number;
    checkedIn: number;
    missing: number;
    medical: number;
    earlyDeparture: number;
  };
  
  byGroup: {
    groupId: string;
    groupName: string;
    total: number;
    checkedIn: number;
    status: 'complete' | 'incomplete' | 'alert';
  }[];
  
  recentActivity: {
    type: 'check_in' | 'missing' | 'found' | 'capture' | 'alert';
    studentName?: string;
    description: string;
    timestamp: Date;
    severity?: AlertSeverity;
  }[];
  
  alerts: {
    id: string;
    type: 'missing' | 'medical' | 'weather' | 'schedule' | 'safety';
    message: string;
    severity: AlertSeverity;
    createdAt: Date;
    acknowledgedAt?: Date;
  }[];
  
  taskProgress: {
    taskId: string;
    taskName: string;
    totalParticipants: number;
    started: number;
    submitted: number;
    completed: number;
  }[];
  
  connectivity: {
    lastServerContact: Date;
    pendingSyncs: number;
    criticalPendingSyncs: number;
  };
}

/**
 * Real-time student status on excursion
 */
export interface StudentExcursionStatus {
  studentId: string;
  studentName: string;
  groupId?: string;
  groupName?: string;
  
  checkInStatus: CheckInStatus;
  lastLocation?: GeoLocation & { timestamp: Date };
  
  tasksCompleted: number;
  totalTasks: number;
  capturesSubmitted: number;
  
  lastActivityAt: Date;
  lastActivityType: string;
  
  alerts?: {
    type: 'off_task' | 'out_of_bounds' | 'inactive' | 'low_battery' | 'sos';
    message: string;
    since: Date;
  }[];
  
  batteryLevel?: number;
  deviceOnline: boolean;
}

// ============================================================================
// LESSON FEEDBACK INTERFACES
// ============================================================================

/**
 * Feedback template for lessons
 */
export interface LessonFeedbackTemplate extends MeshBaseEntity {
  name: string;
  description?: string;
  
  questions: FeedbackQuestion[];
  
  isDefault: boolean;
  subjects?: string[];
  yearLevels?: string[];
  
  estimatedTime: number;
  isAnonymous: boolean;
}

/**
 * Feedback question
 */
export interface FeedbackQuestion {
  id: string;
  text: string;
  type: FeedbackQuestionType;
  
  options?: string[];
  emojiOptions?: string[];
  scaleRange?: { min: number; max: number; labels?: { value: number; label: string }[] };
  
  isRequired: boolean;
  category: 'understanding' | 'engagement' | 'pace' | 'teaching' | 'environment' | 'general';
  order: number;
  
  conditional?: {
    questionId: string;
    condition: 'equals' | 'greater_than' | 'less_than';
    value: any;
  };
}

/**
 * Collected feedback for a session
 */
export interface SessionFeedback extends MeshBaseEntity {
  sessionId: string;
  templateId: string;
  
  openedAt: Date;
  closedAt?: Date;
  
  responses: StudentFeedbackResponse[];
  
  responseRate: {
    total: number;
    responded: number;
    rate: number;
  };
  
  aggregatedResults?: AggregatedFeedback;
  aiInsights?: FeedbackInsights;
  
  teacherReviewed: boolean;
  teacherReviewedAt?: Date;
  teacherNotes?: string;
}

/**
 * Individual student feedback response
 */
export interface StudentFeedbackResponse {
  id: string;
  studentId?: string;
  anonymousId: string;
  
  answers: {
    questionId: string;
    value: any;
    sentiment?: Sentiment;
  }[];
  
  completionTime: number;
  submittedAt: Date;
}

/**
 * Aggregated feedback results
 */
export interface AggregatedFeedback {
  byQuestion: {
    questionId: string;
    questionText: string;
    category: string;
    
    average?: number;
    median?: number;
    distribution?: { value: number; count: number }[];
    
    optionCounts?: { option: string; count: number; percentage: number }[];
    
    yesCount?: number;
    noCount?: number;
    
    sentimentBreakdown?: { sentiment: Sentiment; count: number }[];
    commonThemes?: string[];
  }[];
  
  byCategory: {
    category: string;
    averageScore: number;
    trend: 'improving' | 'stable' | 'declining';
    trendVsPrevious: number;
  }[];
  
  overallScore: number;
  vsSchoolAverage?: number;
  vsSubjectAverage?: number;
}

/**
 * AI-generated feedback insights
 */
export interface FeedbackInsights {
  keyTakeaways: string[];
  strengths: string[];
  improvements: string[];
  
  suggestedActions: {
    action: string;
    priority: 'low' | 'medium' | 'high';
    category: string;
  }[];
  
  sentimentSummary: {
    overall: Sentiment;
    understanding: Sentiment;
    engagement: Sentiment;
  };
  
  anomalies?: string[];
  generatedAt: Date;
}

// ============================================================================
// OFFLINE SYNC INTERFACES
// ============================================================================

/**
 * Offline sync queue item
 */
export interface SyncQueueItem {
  id: string;
  type: 'check_in' | 'roll_call' | 'capture' | 'task_progress' | 'help_request' | 'feedback' | 'alert';
  priority: SyncPriority;
  
  entityType: string;
  entityId: string;
  
  payload: any;
  
  createdAt: Date;
  attempts: number;
  lastAttempt?: Date;
  lastError?: string;
  maxRetries: number;
  
  dependencies?: string[];
}

/**
 * Local record base for offline storage
 */
export interface LocalRecord {
  localId: string;
  serverId: string | null;
  syncStatus: SyncStatus;
  localModifiedAt: Date;
  syncedAt: Date | null;
  version: number;
  serverVersion: number | null;
}

/**
 * Conflict record
 */
export interface ConflictRecord {
  id: string;
  entityType: string;
  entityId: string;
  localVersion: any;
  serverVersion: any;
  conflictFields: string[];
  detectedAt: Date;
  resolvedAt?: Date;
  resolution?: 'local_wins' | 'server_wins' | 'merged' | 'manual';
  resolvedBy?: string;
}

/**
 * Failed critical alert (for manual follow-up)
 */
export interface FailedCriticalAlert {
  id: string;
  alert: SyncQueueItem;
  failedAt: Date;
  attempts: number;
  lastError: string;
  smsAttempted: boolean;
  smsResult?: 'sent' | 'failed';
  manuallyResolved: boolean;
  resolvedAt?: Date;
  resolvedBy?: string;
  resolutionNotes?: string;
}

// ============================================================================
// EVENT TYPES
// ============================================================================

/**
 * Events published by this module
 */
export const CLASSROOM_EXCURSION_EVENTS = {
  // Session events
  SESSION_STARTED: 'classroom.session_started',
  SESSION_ENDED: 'classroom.session_ended',
  
  // Roll call events
  ROLL_CALL_TAKEN: 'classroom.roll_call_taken',
  ATTENDANCE_UPDATED: 'classroom.attendance_updated',
  UNEXPLAINED_ABSENCE: 'classroom.unexplained_absence',
  
  // Seating events
  SEATING_CREATED: 'classroom.seating_created',
  STUDENT_MOVED: 'classroom.student_moved',
  
  // Help request events
  HELP_REQUESTED: 'classroom.help_requested',
  HELP_CRITICAL: 'classroom.help_critical',
  HELP_RESOLVED: 'classroom.help_resolved',
  POST_LESSON_HELP_SUBMITTED: 'classroom.post_lesson_help_submitted',
  
  // Excursion events
  EXCURSION_CREATED: 'excursion.created',
  EXCURSION_APPROVED: 'excursion.approved',
  EXCURSION_STARTED: 'excursion.started',
  EXCURSION_COMPLETED: 'excursion.completed',
  
  // Safety events (CRITICAL)
  CHECKPOINT_COMPLETED: 'excursion.checkpoint_completed',
  STUDENTS_MISSING: 'excursion.students_missing',
  STUDENT_FOUND: 'excursion.student_found',
  HEAD_COUNT_DISCREPANCY: 'excursion.head_count_discrepancy',
  SOS_TRIGGERED: 'excursion.sos_triggered',
  
  // Discovery events
  TASK_STARTED: 'excursion.task_started',
  CAPTURE_SUBMITTED: 'excursion.capture_submitted',
  TASK_SUBMITTED: 'excursion.task_submitted',
  
  // Feedback events
  FEEDBACK_OPENED: 'feedback.collection_opened',
  FEEDBACK_SUBMITTED: 'feedback.response_submitted',
  FEEDBACK_CLOSED: 'feedback.collection_closed',
  LOW_SCORE_ALERT: 'feedback.low_score_alert',
  
  // Sync events
  SYNC_STARTED: 'sync.started',
  SYNC_COMPLETED: 'sync.completed',
  SYNC_CONFLICT: 'sync.conflict',
  OFFLINE_QUEUE_CRITICAL: 'sync.queue_critical',
  CRITICAL_ALERT_FAILED: 'sync.critical_alert_failed'
} as const;

export type ClassroomExcursionEvent = typeof CLASSROOM_EXCURSION_EVENTS[keyof typeof CLASSROOM_EXCURSION_EVENTS];
