# Intelligence Mesh v1.4.1 - Foundation Layer

**Release Date:** January 28, 2026  
**Total Lines of Code:** 9,781  
**Modules Delivered:** Enrollment (with Configurable Forms + Offline Support), Attendance  

---

## Executive Summary

This release delivers the Foundation Layer of the Intelligence Mesh—the first phase in a 36-week programme that transforms Scholarly from a collection of educational tools into a unified intelligence platform.

**Key Capabilities:**
- Configurable enrollment forms (schools design their own questions)
- Full offline support (forms work without internet, sync when back online)
- Attendance tracking with pattern detection
- Event-driven architecture for cross-module intelligence

---

## File Structure

```
/intelligence-mesh (9,781 lines)
├── index.ts                              (161 lines)
├── /shared
│   └── mesh-types.ts                     (947 lines)
├── /events
│   └── mesh-events.ts                    (765 lines)
├── /enrollment
│   ├── enrollment.service.ts             (1,252 lines)
│   ├── enrollment.routes.ts              (335 lines)
│   ├── form-builder.types.ts             (716 lines)
│   ├── form-builder.service.ts           (1,418 lines)
│   ├── form-builder.routes.ts            (329 lines)
│   ├── offline-storage.ts                (1,141 lines)
│   ├── service-worker.ts                 (634 lines)
│   └── offline-react.tsx                 (660 lines)
└── /attendance
    ├── attendance.service.ts             (1,154 lines)
    └── attendance.routes.ts              (269 lines)
```

---

## Offline Capability

### The Problem

A parent sits at the kitchen table after dinner, finally finding 20 minutes to complete the enrollment form on their phone. Halfway through entering medical information:

- The WiFi drops (someone started streaming)
- They walk to check on the kids (lose signal)
- Mobile data is patchy in their area

Without offline support: spinning wheel → error → lost data → frustrated parent.

### The Solution

**With offline support:**

1. **Form keeps working** - Parent doesn't notice connection dropped
2. **Everything saves locally** - IndexedDB stores progress on device
3. **Visual feedback** - Subtle indicator shows "Saved offline" vs "Synced"
4. **Automatic sync** - When connection returns, changes flow to server
5. **Conflict resolution** - If edited on two devices, smart merging handles it

### Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    CLIENT (Browser)                         │
│                                                             │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │ Form UI      │───▶│ Offline      │───▶│ IndexedDB    │  │
│  │ (React)      │    │ Manager      │    │ Storage      │  │
│  └──────────────┘    └──────┬───────┘    └──────────────┘  │
│                             │                               │
│                      ┌──────┴───────┐                       │
│                      │ Service      │                       │
│                      │ Worker       │                       │
│                      └──────┬───────┘                       │
└─────────────────────────────┼───────────────────────────────┘
                              │ (when online)
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    SERVER API                               │
└─────────────────────────────────────────────────────────────┘
```

### Usage

**1. Wrap your app with the provider:**

```tsx
import { OfflineProvider } from '@scholarly/enrollment/offline-react';

function App() {
  return (
    <OfflineProvider 
      config={{ offlineAutoSaveInterval: 5000 }}
      onSyncComplete={(result) => console.log('Synced:', result)}
      onConflict={(conflicts) => showConflictDialog(conflicts)}
    >
      <EnrollmentForm />
    </OfflineProvider>
  );
}
```

**2. Use the form hook:**

```tsx
import { 
  useOfflineForm, 
  OfflineIndicator, 
  SyncStatus,
  AutoSaveIndicator 
} from '@scholarly/enrollment/offline-react';

function EnrollmentForm({ formConfigId, tenantId }) {
  const {
    submission,
    saveField,
    submitForm,
    isOnline,
    isSyncing,
    pendingSyncCount,
    lastSaved
  } = useOfflineForm(formConfigId, tenantId);

  return (
    <form>
      <OfflineIndicator position="bottom-right" />
      
      <input
        value={submission?.responses.find(r => r.fieldId === 'firstName')?.value || ''}
        onChange={(e) => saveField('firstName', e.target.value)}
      />
      
      <SyncStatus />
      <AutoSaveIndicator lastSaved={lastSaved} />
      
      <button onClick={submitForm} disabled={!isOnline}>
        Submit
      </button>
    </form>
  );
}
```

### Key Features

| Feature | Description |
|---------|-------------|
| **IndexedDB Storage** | Submissions stored locally |
| **Service Worker** | Serves cached content when offline |
| **Sync Queue** | Failed requests queued and retried |
| **Background Sync** | Uses Background Sync API |
| **Conflict Resolution** | Detects and resolves edit conflicts |
| **Connection Quality** | Adapts based on connection speed |
| **Auto-save** | Configurable debounced saving |

### Configuration

```typescript
const config: OfflineConfig = {
  enabled: true,
  dbName: 'scholarly-enrollment-offline',
  formConfigCacheDuration: 24 * 60 * 60 * 1000,  // 24 hours
  offlineAutoSaveInterval: 5000,                   // 5 seconds
  maxQueueSize: 100,
  maxSyncRetries: 5,
  defaultConflictStrategy: 'merge',
  useBackgroundSync: true,
  minConnectionForSync: '3g'
};
```

---

## Configurable Enrollment Forms

Schools design custom enrollment forms while maintaining data consistency:

- **30+ field types**: text, select, file, date, signature, address, consent, etc.
- **Conditional logic**: show/hide fields based on other values
- **Custom validation**: regex patterns, cross-field rules
- **Repeatable sections**: multiple guardians, siblings
- **Field mapping**: custom fields → standard data model

### Example

```typescript
// Add a custom field
await formBuilder.addField(tenantId, formId, sectionId, {
  type: 'multi_select',
  label: 'How does your child learn best?',
  config: {
    type: 'multi_select',
    options: [
      { value: 'visual', label: 'Visual (diagrams, videos)' },
      { value: 'auditory', label: 'Auditory (listening)' },
      { value: 'kinesthetic', label: 'Hands-on activities' }
    ],
    allowOther: true
  },
  customDataKey: 'learningPreferences'
});
```

---

## Attendance Module

Daily presence tracking with intelligence:

- **Multiple inputs**: Teacher roll call, kiosk, NFC/biometric, parent app
- **Pattern detection**: Monday/Friday absences, trends, chronic lateness
- **Risk scoring**: Chronic absenteeism prediction
- **Alert management**: Auto-escalation, acknowledgment, resolution

---

## Event Architecture

Cross-module intelligence via NATS:

```
scholarly.enrollment.*    (15 events)
scholarly.attendance.*    (18 events)
scholarly.assessment.*    (8 events - preview)
scholarly.gradebook.*     (6 events - preview)
scholarly.wellbeing.*     (12 events - preview)
scholarly.parent.*        (11 events - preview)
scholarly.mesh.*          (9 cross-module)
```

---

## What's Next

### v1.5.0 - Assessment & Gradebook (Weeks 13-24)
- Assessment Module (Formative + Summative)
- AI-assisted marking pipeline
- Standards-Based Gradebook

### v1.6.0 - Wellbeing & Portal (Weeks 25-36)
- Student Wellbeing Module
- Parent Portal with Intelligence Layer
- Cross-module signal synthesis

---

*Intelligence Mesh v1.4.1 - Foundation Layer*  
*Scholarly Platform | January 2026*
