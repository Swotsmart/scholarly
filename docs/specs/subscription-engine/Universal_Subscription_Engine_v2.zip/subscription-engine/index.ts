/**
 * Universal Subscription Engine
 * 
 * A comprehensive, multi-platform subscription management system.
 * 
 * Features:
 * - Multi-tenant, multi-vendor subscription management
 * - KYC-gated plan access with credential requirements
 * - Seat-based pricing for institutional customers
 * - Intent-based trial system with conversion tracking
 * - Family/group subscription support
 * - Institutional billing (invoicing, purchase orders)
 * - Credential-linked entitlements with expiry handling
 * - Flexible revenue share mechanics
 * - Comprehensive analytics
 * 
 * Designed for use across:
 * - Chekd-ID (identity and trust platform)
 * - Scholarly (education platform)
 * - Future Chekd ecosystem products
 * 
 * @version 2.0.0
 * @author Chekd Platform Team
 */

// Export all types
export * from './types';

// Export the main service
export { UniversalSubscriptionService } from './subscription.service';

// Export error classes
export {
  SubscriptionError,
  KycRequiredError,
  PlanNotFoundError,
  SubscriptionNotFoundError,
  PlanCapacityError,
  InvalidStateError,
  SeatLimitError,
  MemberLimitError,
  CredentialExpiredError
} from './subscription.service';

// Export result type helpers
export { Result, success, failure } from './subscription.service';

// Re-export platform module definitions for convenience
export { CHEKD_MODULES, SCHOLARLY_MODULES } from './types';
