/**
 * Universal Identity, KYC/KYB & Trust Engine
 * 
 * A comprehensive identity verification and trust scoring system designed
 * for multi-platform use across the Chekd ecosystem.
 * 
 * Components:
 * - Identity Service: Core identity management, profiles, contacts
 * - KYC Service: Individual verification with multi-provider support
 * - KYB Service: Business verification and compliance
 * - Trust Service: Reputation scoring and risk assessment
 * 
 * @version 1.0.0
 * @author Chekd Platform Team
 */

// ============================================================================
// TYPE EXPORTS
// ============================================================================

export * from './types';

// ============================================================================
// SERVICE EXPORTS
// ============================================================================

// Identity Service
export { 
  IdentityService,
  IdentityError,
  IdentityNotFoundError,
  ContactVerificationError,
  DuplicateIdentityError,
  Result,
  success,
  failure
} from './identity.service';

// KYB Service
export {
  KybService,
  BusinessVerificationError,
  BusinessNotFoundError
} from './kyb.service';

// Trust Service
export {
  TrustService
} from './trust.service';

// ============================================================================
// CONFIGURATION HELPERS
// ============================================================================

import { 
  VerificationProvider, 
  CredentialType, 
  Jurisdiction,
  ProviderConfig 
} from './types';

/**
 * Credential type to display name mapping
 */
export const CREDENTIAL_DISPLAY_NAMES: Record<CredentialType, string> = {
  [CredentialType.WWCC_NSW]: 'NSW Working With Children Check',
  [CredentialType.WWCC_VIC]: 'VIC Working With Children Check',
  [CredentialType.WWCC_QLD]: 'QLD Blue Card',
  [CredentialType.WWCC_WA]: 'WA Working With Children Check',
  [CredentialType.WWCC_SA]: 'SA Working With Children Check',
  [CredentialType.WWCC_TAS]: 'TAS Working With Children Check',
  [CredentialType.WWCC_ACT]: 'ACT Working With Vulnerable People',
  [CredentialType.WWCC_NT]: 'NT Working With Children (Ochre Card)',
  [CredentialType.DBS_BASIC]: 'DBS Basic Check',
  [CredentialType.DBS_STANDARD]: 'DBS Standard Check',
  [CredentialType.DBS_ENHANCED]: 'DBS Enhanced Check',
  [CredentialType.PVG_SCOTLAND]: 'PVG Scheme (Scotland)',
  [CredentialType.VSC_CANADA]: 'Vulnerable Sector Check (Canada)',
  [CredentialType.NESA_NSW]: 'NESA Teaching Accreditation',
  [CredentialType.VIT_VIC]: 'VIT Teaching Registration',
  [CredentialType.QCT_QLD]: 'QCT Teaching Registration',
  [CredentialType.TRBWA_WA]: 'TRBWA Teaching Registration',
  [CredentialType.TRB_SA]: 'TRB SA Teaching Registration',
  [CredentialType.TRB_TAS]: 'TRB TAS Teaching Registration',
  [CredentialType.TRB_ACT]: 'TRB ACT Teaching Registration',
  [CredentialType.TRB_NT]: 'TRB NT Teaching Registration',
  [CredentialType.FIRST_AID]: 'First Aid Certificate',
  [CredentialType.CPR]: 'CPR Certificate',
  [CredentialType.ANAPHYLAXIS]: 'Anaphylaxis Training',
  [CredentialType.FOOD_SAFETY]: 'Food Safety Certificate',
  [CredentialType.RSA]: 'Responsible Service of Alcohol',
  [CredentialType.RCG]: 'Responsible Conduct of Gambling',
  [CredentialType.SECURITY_LICENSE]: 'Security License',
  [CredentialType.ABN]: 'Australian Business Number',
  [CredentialType.ACN]: 'Australian Company Number',
  [CredentialType.GST_REGISTRATION]: 'GST Registration',
  [CredentialType.BACHELOR_DEGREE]: 'Bachelor Degree',
  [CredentialType.MASTER_DEGREE]: 'Master Degree',
  [CredentialType.DOCTORATE]: 'Doctorate',
  [CredentialType.DIPLOMA]: 'Diploma',
  [CredentialType.CERTIFICATE]: 'Certificate',
  [CredentialType.PUBLIC_LIABILITY]: 'Public Liability Insurance',
  [CredentialType.PROFESSIONAL_INDEMNITY]: 'Professional Indemnity Insurance',
  [CredentialType.PLATFORM_VERIFIED]: 'Platform Verified',
  [CredentialType.PLATFORM_TRUSTED]: 'Platform Trusted Member'
};

/**
 * Jurisdiction to display name mapping
 */
export const JURISDICTION_DISPLAY_NAMES: Record<Jurisdiction, string> = {
  [Jurisdiction.AU_NSW]: 'New South Wales, Australia',
  [Jurisdiction.AU_VIC]: 'Victoria, Australia',
  [Jurisdiction.AU_QLD]: 'Queensland, Australia',
  [Jurisdiction.AU_WA]: 'Western Australia',
  [Jurisdiction.AU_SA]: 'South Australia',
  [Jurisdiction.AU_TAS]: 'Tasmania, Australia',
  [Jurisdiction.AU_ACT]: 'Australian Capital Territory',
  [Jurisdiction.AU_NT]: 'Northern Territory, Australia',
  [Jurisdiction.UK_ENGLAND]: 'England, United Kingdom',
  [Jurisdiction.UK_SCOTLAND]: 'Scotland, United Kingdom',
  [Jurisdiction.UK_WALES]: 'Wales, United Kingdom',
  [Jurisdiction.UK_NI]: 'Northern Ireland, United Kingdom',
  [Jurisdiction.NZ]: 'New Zealand',
  [Jurisdiction.US]: 'United States',
  [Jurisdiction.CA]: 'Canada',
  [Jurisdiction.SG]: 'Singapore',
  [Jurisdiction.INTERNATIONAL]: 'International'
};

/**
 * Get WWCC credential type for Australian state
 */
export function getWwccTypeForState(state: string): CredentialType | null {
  const mapping: Record<string, CredentialType> = {
    'NSW': CredentialType.WWCC_NSW,
    'VIC': CredentialType.WWCC_VIC,
    'QLD': CredentialType.WWCC_QLD,
    'WA': CredentialType.WWCC_WA,
    'SA': CredentialType.WWCC_SA,
    'TAS': CredentialType.WWCC_TAS,
    'ACT': CredentialType.WWCC_ACT,
    'NT': CredentialType.WWCC_NT
  };
  return mapping[state.toUpperCase()] || null;
}

/**
 * Get teaching registration credential type for Australian state
 */
export function getTeachingRegTypeForState(state: string): CredentialType | null {
  const mapping: Record<string, CredentialType> = {
    'NSW': CredentialType.NESA_NSW,
    'VIC': CredentialType.VIT_VIC,
    'QLD': CredentialType.QCT_QLD,
    'WA': CredentialType.TRBWA_WA,
    'SA': CredentialType.TRB_SA,
    'TAS': CredentialType.TRB_TAS,
    'ACT': CredentialType.TRB_ACT,
    'NT': CredentialType.TRB_NT
  };
  return mapping[state.toUpperCase()] || null;
}

/**
 * Get jurisdiction from Australian state code
 */
export function getJurisdictionForAustralianState(state: string): Jurisdiction | null {
  const mapping: Record<string, Jurisdiction> = {
    'NSW': Jurisdiction.AU_NSW,
    'VIC': Jurisdiction.AU_VIC,
    'QLD': Jurisdiction.AU_QLD,
    'WA': Jurisdiction.AU_WA,
    'SA': Jurisdiction.AU_SA,
    'TAS': Jurisdiction.AU_TAS,
    'ACT': Jurisdiction.AU_ACT,
    'NT': Jurisdiction.AU_NT
  };
  return mapping[state.toUpperCase()] || null;
}

/**
 * Check if a credential type is a safeguarding credential (WWCC/DBS/etc)
 */
export function isSafeguardingCredential(type: CredentialType): boolean {
  const safeguardingTypes = [
    CredentialType.WWCC_NSW, CredentialType.WWCC_VIC, CredentialType.WWCC_QLD,
    CredentialType.WWCC_WA, CredentialType.WWCC_SA, CredentialType.WWCC_TAS,
    CredentialType.WWCC_ACT, CredentialType.WWCC_NT,
    CredentialType.DBS_BASIC, CredentialType.DBS_STANDARD, CredentialType.DBS_ENHANCED,
    CredentialType.PVG_SCOTLAND, CredentialType.VSC_CANADA
  ];
  return safeguardingTypes.includes(type);
}

/**
 * Check if a credential type is a teaching credential
 */
export function isTeachingCredential(type: CredentialType): boolean {
  const teachingTypes = [
    CredentialType.NESA_NSW, CredentialType.VIT_VIC, CredentialType.QCT_QLD,
    CredentialType.TRBWA_WA, CredentialType.TRB_SA, CredentialType.TRB_TAS,
    CredentialType.TRB_ACT, CredentialType.TRB_NT
  ];
  return teachingTypes.includes(type);
}

/**
 * Check if a credential type is a business credential
 */
export function isBusinessCredential(type: CredentialType): boolean {
  const businessTypes = [
    CredentialType.ABN, CredentialType.ACN, CredentialType.GST_REGISTRATION
  ];
  return businessTypes.includes(type);
}
