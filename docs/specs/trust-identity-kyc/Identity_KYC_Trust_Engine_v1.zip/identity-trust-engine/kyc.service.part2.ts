/**
 * KYC Service - Part 2
 * 
 * Continuation with remaining methods
 */

import {
  Identity,
  IdentityStatus,
  KycLevel,
  VerificationSession,
  VerificationCheck,
  VerificationCheckType,
  VerificationCheckStatus,
  VerificationResult,
  Credential,
  CredentialType,
  CredentialStatus,
  VerificationProvider,
  DocumentType,
  Jurisdiction,
} from './types';

// Continuation of KycService class methods...

export class KycServicePart2 {

  /**
   * Check if user has a specific credential (valid)
   */
  async hasCredential(
    tenantId: string,
    userId: string,
    credentialType: CredentialType
  ): Promise<Result<boolean>> {
    try {
      const identity = await this.repo.findByUserId(tenantId, userId);
      if (!identity) {
        return success(false);
      }

      const credential = identity.credentials.find(
        c => c.type === credentialType && c.status === CredentialStatus.VALID
      );

      return success(!!credential);
    } catch (error) {
      return failure(error as Error);
    }
  }

  /**
   * Get missing credentials from a required list
   */
  async getMissingCredentials(
    tenantId: string,
    userId: string,
    requiredCredentials: CredentialType[]
  ): Promise<Result<CredentialType[]>> {
    try {
      const identity = await this.repo.findByUserId(tenantId, userId);
      if (!identity) {
        return success(requiredCredentials); // All missing if no identity
      }

      const validCredentials = new Set(
        identity.credentials
          .filter(c => c.status === CredentialStatus.VALID)
          .map(c => c.type)
      );

      const missing = requiredCredentials.filter(c => !validCredentials.has(c));
      return success(missing);
    } catch (error) {
      return failure(error as Error);
    }
  }

  /**
   * Get expired credentials
   */
  async getExpiredCredentials(
    tenantId: string,
    userId: string
  ): Promise<Result<CredentialType[]>> {
    try {
      const identity = await this.repo.findByUserId(tenantId, userId);
      if (!identity) {
        return success([]);
      }

      const expired = identity.credentials
        .filter(c => c.status === CredentialStatus.EXPIRED)
        .map(c => c.type);

      return success(expired);
    } catch (error) {
      return failure(error as Error);
    }
  }

  /**
   * Get verification URL for a user to complete KYC
   */
  async getVerificationUrl(
    tenantId: string,
    userId: string,
    targetLevel: KycLevel
  ): Promise<Result<string>> {
    try {
      const identity = await this.repo.findByUserId(tenantId, userId);
      if (!identity) {
        return failure(new IdentityNotFoundError(`userId:${userId}`));
      }

      // Check for existing active session
      // In production, would query for active sessions
      
      // Start new verification session
      const sessionResult = await this.startVerification(tenantId, identity.id, {
        targetLevel,
        redirectUrl: `${this.config.platformBaseUrl}/verification/complete`
      });

      if (!sessionResult.success) {
        return failure(sessionResult.error);
      }

      return success(sessionResult.data.verificationUrl || 
        `${this.config.platformBaseUrl}/verification/${sessionResult.data.id}`);
    } catch (error) {
      return failure(error as Error);
    }
  }

  // ==========================================================================
  // INTERNAL METHODS
  // ==========================================================================

  /**
   * Update session from provider status
   */
  private async updateSessionFromProvider(
    session: VerificationSession,
    providerStatus: {
      status: VerificationSession['status'];
      checks: VerificationCheck[];
      result?: VerificationResult;
    }
  ): Promise<void> {
    const updates: Partial<VerificationSession> = {
      status: providerStatus.status,
      checks: providerStatus.checks
    };

    if (providerStatus.result) {
      updates.result = providerStatus.result;
      updates.completedAt = new Date();

      // If completed successfully, update identity
      if (providerStatus.result.outcome === 'approved') {
        await this.completeVerification(session, providerStatus.result);
      }
    }

    await this.repo.updateSession(session.id, updates);
  }

  /**
   * Handle check completed event
   */
  private async handleCheckCompleted(
    session: VerificationSession,
    data: any
  ): Promise<void> {
    const checkIndex = session.checks.findIndex(c => c.externalCheckId === data.checkId);
    if (checkIndex >= 0) {
      session.checks[checkIndex] = {
        ...session.checks[checkIndex],
        status: data.passed ? VerificationCheckStatus.PASSED : VerificationCheckStatus.FAILED,
        confidenceScore: data.confidenceScore,
        resultData: data.details,
        completedAt: new Date()
      };

      await this.repo.updateSession(session.id, { checks: session.checks });
    }
  }

  /**
   * Handle verification completed event
   */
  private async handleVerificationCompleted(
    session: VerificationSession,
    data: any
  ): Promise<void> {
    const result: VerificationResult = {
      outcome: data.outcome,
      achievedLevel: data.outcome === 'approved' ? session.targetLevel : undefined,
      confidenceScore: data.confidenceScore || 0,
      checksSummary: {
        total: session.checks.length,
        passed: session.checks.filter(c => c.status === VerificationCheckStatus.PASSED).length,
        failed: session.checks.filter(c => c.status === VerificationCheckStatus.FAILED).length,
        needsReview: session.checks.filter(c => c.status === VerificationCheckStatus.NEEDS_REVIEW).length
      },
      verifiedProfile: data.extractedData,
      providerResponse: data
    };

    await this.repo.updateSession(session.id, {
      status: 'completed',
      completedAt: new Date(),
      result
    });

    if (result.outcome === 'approved') {
      await this.completeVerification(session, result);
    } else if (result.outcome === 'review_required') {
      await this.repo.updateSession(session.id, { status: 'pending_review' });
      await this.publishEvent('kyc.review_required', session.tenantId, {
        identityId: session.identityId,
        sessionId: session.id
      });
    }
  }

  /**
   * Handle verification failed event
   */
  private async handleVerificationFailed(
    session: VerificationSession,
    data: any
  ): Promise<void> {
    await this.repo.updateSession(session.id, {
      status: 'failed',
      completedAt: new Date(),
      result: {
        outcome: 'rejected',
        confidenceScore: 0,
        checksSummary: {
          total: session.checks.length,
          passed: 0,
          failed: session.checks.length,
          needsReview: 0
        },
        riskIndicators: data.failureReasons || ['Verification failed']
      }
    });

    await this.publishEvent('kyc.verification_failed', session.tenantId, {
      identityId: session.identityId,
      sessionId: session.id,
      reasons: data.failureReasons
    });
  }

  /**
   * Handle document uploaded event
   */
  private async handleDocumentUploaded(
    session: VerificationSession,
    data: any
  ): Promise<void> {
    const document: CollectedDocument = {
      id: this.generateId(),
      sessionId: session.id,
      type: data.documentType,
      issuingCountry: data.issuingCountry,
      documentNumber: data.documentNumber ? this.maskDocumentNumber(data.documentNumber) : undefined,
      expiryDate: data.expiryDate ? new Date(data.expiryDate) : undefined,
      isStored: true,
      extractedData: data.extractedData,
      verificationStatus: 'pending',
      createdAt: new Date()
    };

    session.documents.push(document);
    await this.repo.updateSession(session.id, { documents: session.documents });
  }

  /**
   * Complete a successful verification
   */
  private async completeVerification(
    session: VerificationSession,
    result: VerificationResult,
    reviewerId?: string,
    notes?: string
  ): Promise<void> {
    const identity = await this.repo.findById(session.tenantId, session.identityId);
    if (!identity) return;

    // Update identity profile if data was extracted
    if (result.verifiedProfile) {
      await this.repo.update(identity.id, {
        profile: {
          ...identity.profile,
          ...result.verifiedProfile,
          isVerified: true,
          verifiedAt: new Date(),
          verificationSource: session.provider
        }
      });
    }

    // Update KYC level
    const newLevel = result.achievedLevel || session.targetLevel || KycLevel.STANDARD;
    const newStatus = this.getStatusForLevel(newLevel);

    await this.repo.update(identity.id, {
      kycLevel: newLevel,
      status: newStatus,
      lastVerifiedAt: new Date()
    });

    // Create verification record
    const verificationRecord: VerificationRecord = {
      id: this.generateId(),
      identityId: identity.id,
      sessionId: session.id,
      type: 'kyc',
      provider: session.provider,
      previousLevel: identity.kycLevel,
      newLevel,
      outcome: result.outcome,
      checksPerformed: session.checks.map(c => c.type),
      documentsVerified: session.documents.map(d => d.type),
      verifiedAt: new Date(),
      notes
    };

    // Store verification record
    identity.verifications.push(verificationRecord);
    await this.repo.update(identity.id, { verifications: identity.verifications });

    await this.audit('verification', session.id, 'completed', session.tenantId, reviewerId || 'system', {
      outcome: result.outcome,
      previousLevel: identity.kycLevel,
      newLevel
    });

    await this.publishEvent('kyc.verification_completed', session.tenantId, {
      identityId: identity.id,
      sessionId: session.id,
      previousLevel: identity.kycLevel,
      newLevel,
      outcome: result.outcome
    });
  }

  /**
   * Check and upgrade KYC level based on credential
   */
  private async checkAndUpgradeKycLevel(
    identity: Identity,
    credential: Credential
  ): Promise<void> {
    // If identity already has enhanced level, nothing to do
    if (identity.kycLevel >= KycLevel.ENHANCED) return;

    // Check if profile is verified (required for enhanced)
    if (!identity.profile.isVerified) return;

    // Upgrade to enhanced
    await this.repo.update(identity.id, {
      kycLevel: KycLevel.ENHANCED,
      status: IdentityStatus.ENHANCED
    });

    await this.publishEvent('kyc.level_upgraded', identity.tenantId, {
      identityId: identity.id,
      previousLevel: identity.kycLevel,
      newLevel: KycLevel.ENHANCED,
      triggerCredential: credential.type
    });
  }

  // ==========================================================================
  // HELPER METHODS
  // ==========================================================================

  /**
   * Get required checks for a target KYC level
   */
  private getRequiredChecks(
    targetLevel: KycLevel,
    currentLevel: KycLevel
  ): VerificationCheckType[] {
    const checks: VerificationCheckType[] = [];

    if (targetLevel >= KycLevel.BASIC && currentLevel < KycLevel.BASIC) {
      checks.push(VerificationCheckType.EMAIL);
    }

    if (targetLevel >= KycLevel.STANDARD) {
      checks.push(
        VerificationCheckType.DOCUMENT,
        VerificationCheckType.BIOMETRIC,
        VerificationCheckType.LIVENESS
      );
    }

    // Always include watchlist for standard and above
    if (targetLevel >= KycLevel.STANDARD) {
      checks.push(
        VerificationCheckType.WATCHLIST,
        VerificationCheckType.PEP,
        VerificationCheckType.SANCTIONS
      );
    }

    return checks;
  }

  /**
   * Get required documents for a target KYC level
   */
  private getRequiredDocuments(targetLevel: KycLevel): DocumentType[] {
    if (targetLevel >= KycLevel.STANDARD) {
      return [
        DocumentType.PASSPORT,
        DocumentType.DRIVERS_LICENSE,
        DocumentType.SELFIE
      ];
    }
    return [];
  }

  /**
   * Map country code to jurisdiction
   */
  private mapCountryToJurisdiction(countryCode: string): Jurisdiction {
    const mapping: Record<string, Jurisdiction> = {
      'AU': Jurisdiction.AU_NSW, // Default to NSW
      'GB': Jurisdiction.UK_ENGLAND,
      'NZ': Jurisdiction.NZ,
      'US': Jurisdiction.US,
      'CA': Jurisdiction.CA,
      'SG': Jurisdiction.SG
    };
    return mapping[countryCode] || Jurisdiction.INTERNATIONAL;
  }

  /**
   * Get default issuer for a credential type
   */
  private getDefaultIssuer(type: CredentialType, jurisdiction: Jurisdiction): string {
    const issuers: Partial<Record<CredentialType, string>> = {
      [CredentialType.WWCC_NSW]: 'Office of the Children\'s Guardian NSW',
      [CredentialType.WWCC_VIC]: 'Department of Justice Victoria',
      [CredentialType.NESA_NSW]: 'NSW Education Standards Authority',
      [CredentialType.VIT_VIC]: 'Victorian Institute of Teaching',
      [CredentialType.DBS_ENHANCED]: 'Disclosure and Barring Service',
      [CredentialType.ABN]: 'Australian Business Register',
      [CredentialType.ACN]: 'Australian Securities and Investments Commission'
    };
    return issuers[type] || 'Unknown';
  }

  /**
   * Calculate next verification date for a credential
   */
  private calculateNextVerification(type: CredentialType): Date {
    // Different credentials have different refresh intervals
    const refreshDays: Partial<Record<CredentialType, number>> = {
      [CredentialType.WWCC_NSW]: 7, // Weekly check
      [CredentialType.WWCC_VIC]: 7,
      [CredentialType.NESA_NSW]: 30, // Monthly check
      [CredentialType.ABN]: 90, // Quarterly check
    };

    const days = refreshDays[type] || 30;
    return new Date(Date.now() + days * 24 * 60 * 60 * 1000);
  }

  /**
   * Get identity status for KYC level
   */
  private getStatusForLevel(level: KycLevel): IdentityStatus {
    switch (level) {
      case KycLevel.NONE: return IdentityStatus.UNVERIFIED;
      case KycLevel.BASIC: return IdentityStatus.BASIC;
      case KycLevel.STANDARD: return IdentityStatus.VERIFIED;
      case KycLevel.ENHANCED: return IdentityStatus.ENHANCED;
      case KycLevel.BUSINESS: return IdentityStatus.ENHANCED;
      default: return IdentityStatus.UNVERIFIED;
    }
  }

  /**
   * Format credential type for display
   */
  private formatCredentialType(type: CredentialType): string {
    const names: Partial<Record<CredentialType, string>> = {
      [CredentialType.WWCC_NSW]: 'NSW Working With Children Check',
      [CredentialType.WWCC_VIC]: 'VIC Working With Children Check',
      [CredentialType.WWCC_QLD]: 'QLD Blue Card',
      [CredentialType.NESA_NSW]: 'NESA Teaching Accreditation',
      [CredentialType.VIT_VIC]: 'VIT Teaching Registration',
      [CredentialType.DBS_ENHANCED]: 'DBS Enhanced Check',
      [CredentialType.FIRST_AID]: 'First Aid Certificate',
      [CredentialType.ABN]: 'Australian Business Number',
      [CredentialType.ACN]: 'Australian Company Number'
    };
    return names[type] || type.replace(/_/g, ' ').toUpperCase();
  }

  /**
   * Mask document number for storage
   */
  private maskDocumentNumber(number: string): string {
    if (number.length <= 4) return '****';
    return '*'.repeat(number.length - 4) + number.slice(-4);
  }

  private generateId(): string {
    return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private async audit(
    entityType: string,
    entityId: string,
    action: string,
    tenantId: string,
    actorId: string,
    details?: Record<string, any>
  ): Promise<void> {
    await this.repo.createAuditLog({
      tenantId,
      entityType: entityType as any,
      entityId,
      action,
      actorType: actorId === 'system' ? 'system' : 'user',
      actorId,
      changes: details ? [{ field: 'action', oldValue: null, newValue: details }] : undefined,
      timestamp: new Date()
    });
  }

  private async publishEvent(
    type: string,
    tenantId: string,
    data: Record<string, any>
  ): Promise<void> {
    await this.eventBus.publish(type, tenantId, {
      type,
      timestamp: new Date().toISOString(),
      ...data
    });
  }
}

// Type imports for Result
import { Result, success, failure, IdentityNotFoundError } from './identity.service';
